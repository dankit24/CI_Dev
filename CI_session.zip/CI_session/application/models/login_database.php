<?php

Class Login_Database extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

// Insert registration data in database
    public function registration_insert($data) {
// Query to insert data in database
        $query = $this->db->insert('user_login', $data);

        if ($this->db->affected_rows() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

// Read data using username and password
    public function login($data) {

        $condition = "user_name ="."'".$data['username']."'";
        $this->db->select('user_password');
        $this->db->from('user_login');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();
        $result = $query->result_array();
        
        if ($query->num_rows() == 1 && password_verify($data['password'], $result[0]['user_password'])) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

// Read data from database to show data in admin page
    public function read_user_information($username) {

        $condition = "user_name =" . "'" . $username . "'";
        $this->db->select('*');
        $this->db->from('user_login');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return FALSE;
        }
    }

}

?>