<?php

error_reporting(0);

class Shoppingcart extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library(array('form_validation'));
        $this->load->helper(array('url', 'form'));
        $this->load->model('products');
        $this->load->model('cartstatus');
    }

    public function index() {
        $this->output->enable_profiler();
        $products = $this->products->loadproducts();
        $this->session->set_userdata('products', $products);
        $config = array(
            array('field' => 'qty',
                'label' => 'Quantity',
                'rules' => 'required'),
        );

        $this->form_validation->set_rules($config);
        if ($this->form_validation->run() == FALSE) {
            $load = $this->cartstatus->loadcart();
            $this->load->view('home',$load);
        } else {
            $msg = array('succstatus' => 'Product successfuly added to cart');
            $data = array('product' => $_GET['p'], 'qty' => $_POST['qty']);
            $status = $this->cartstatus->addtocart($data, $products);
            $load = $this->cartstatus->loadcart();
            $this->load->view('home', $load);
        }
    }

    public function emptycart() {
        $this->output->enable_profiler();

        $products = $this->products->loadproducts();
        $this->cartstatus->emptycart();
        $this->load->view('home');
    }

    public function removeitem() {
        $this->output->enable_profiler();

        $products = $this->products->loadproducts();
        $data = array('removeid' => $_GET['deleteId']);
        $this->cartstatus->removeitem($data);
        $load = $this->cartstatus->loadcart();
        $this->load->view('home',$load);
    }

}
