<?php

class cartstatus extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function addtocart($data, $products) {
//        $products = $products[$data['product']];
//        $products['qty'] += $data['qty'];
//        print_r($products);

        $products[$data['product']]['qty'] = $data['qty'];
        $this->session->set_userdata('cart', $products);
    }

    public function emptycart() {
        $this->session->unset_userdata('cart');
        $this->session->sess_destroy();
    }

    public function removeitem($data) {
        $oldcart = $this->session->userdata('cart');
        unset($oldcart[$data['removeid']]);
        $this->session->set_userdata('cart', $oldcart);
    }

    public function loadcart() {
        $disitem = $this->session->userdata('cart');
        foreach ($disitem as $key => $row) {
            if ($row['qty'] >> 0) {
                $data[] = array($key => array('name' => "<tr><td>" . $row['name'] . "</td>",
                        'code' => "<td>" . $row['code'] . "</td>",
                        'qty' => "<td>" . $row['qty'] . "</td>",
                        'price' => "<td>" . $row['price'] . "</td>",
                        'total' => "<td>" . $row['qty']*$row['price'] . "</td>",
                        'action' => "<td align='center'><a href=" . base_url() . "shoppingcart/removeitem?deleteId=$key>Remove Item</a></td></tr>",
                ));
            }
        }
        $data = array('products'=>$data);
        return $data;
    }

}
