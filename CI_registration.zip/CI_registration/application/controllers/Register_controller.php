<?php

class Register_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url','captcha'));
        $this->load->library(array('form_validation','session'));
        $this->load->database();
        $this->load->model('register_model');
    }

    public function index() {
        $this->output->enable_profiler();
        $this->load->view('templetes/header');

        $this->form_validation->set_error_delimiters('<label class="error">', '</label>');

        $config = array(
            array(
                'field' => 'firstname',
                'label' => 'First Name',
                'rules' => 'trim|required|alpha',
                'errors' => array(
                    'required' => '%s is required',
                    'alpha' => '%s should contain only alphabets',
                ),
            ),
            array(
                'field' => 'lastname',
                'label' => 'Last Name',
                'rules' => 'trim|required|alpha',
                'errors' => array(
                    'required' => '%s is required',
                    'alpha' => '%s should contain only alphabets',
                ),
            ),
            array(
                'field' => 'username',
                'label' => 'User Name',
                'rules' => 'trim|required|min_length[6]|alpha_numeric|is_unique[test.username]',
                'errors' => array(
                    'required' => '%s is required',
                    'alpha_numeric' => '%s should contain only alphabets and number',
                    'min_length' => 'min length of %s should be 6',
                    'is_unique' => '%s already registered',
                ),
            ),
            array(
                'field' => 'gender',
                'label' => 'Gender',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s is required',
                ),
            ),
            array(
                'field' => 'birthdate',
                'label' => 'Birth Date',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s is required',
                ),
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|valid_email|is_unique[test.email]',
                'errors' => array(
                    'required' => '%s is required',
                    'valid_email' => '%s should be valid email',
                    'is_unique' => '%s already registered',
                ),
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'trim|required|min_length[8]',
                'errors' => array(
                    'required' => '%s is required',
                    'min_length' => 'min length of %s should be 8',
                ),
            ),
            array(
                'field' => 'passconf',
                'label' => 'Confirmation Password',
                'rules' => 'trim|required|matches[password]',
                'errors' => array(
                    'required' => '%s is required',
                    'matches' => 'does not match with password',
                ),
            ),
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE) {

            if (isset($this->session->userdata['logged_in'])) {
                $this->load->view('pages/home');
            } else {
                $msg = array('statusmsg' => '');
                $this->load->view('pages/register_form', $msg);
            }
        } else {
            $data = array(
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'username' => $this->input->post('username'),
                'birthdate' => $this->input->post('birthdate'),
                'gender' => $this->input->post('gender'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            );

            $result = $this->register_model->register($data);

            if ($result == TRUE) {
                $msg = array('statusmsg' => 'Registration Successful',);
                $this->load->view('pages/login_form', $msg);
            } else {
                $msg = array('statusmsg' => 'Problem Registering User');

                $this->load->view('pages/register', $msg);
            }
        }
        $this->load->view('templetes/footer');
    }

}
