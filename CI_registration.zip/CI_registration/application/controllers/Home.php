<?php

class Home extends CI_Controller {

    public function index() {
        $this->output->enable_profiler(TRUE);
        $this->benchmark->mark('code_start');
        
        $this->load->helper(array('form', 'url'));
        
        $this->load->library(array('form_validation'));
        
        $this->load->database();
        
        $this->form_validation->set_error_delimiters('<label class="error">','</label>');

        
        $config = array(
            array(
                'field' => 'firstname',
                'label' => 'First Name',
                'rules' => 'trim|required|alpha',
                'errors' => array(
                  'required' => '%s is required',
                    'alpha' => '%s should contain only alphabets',
                ),
            ),
            array(
                'field' => 'lastname',
                'label' => 'Last Name',
                'rules' => 'trim|required|alpha',
                'errors' => array(
                  'required' => '%s is required',
                    'alpha' => '%s should contain only alphabets',
                ),
            ),
            array(
                'field' => 'username',
                'label' => 'User Name',
                'rules' => 'trim|required|min_length[6]|alpha_numeric|is_unique[test.username]',
                'errors' => array(
                  'required' => '%s is required',
                    'alpha_numeric' => '%s should contain only alphabets and number',
                    'min_length' => 'min length of %s should be 6',
                    'is_unique' => '%s already registered',
                ),
            ),
            array(
                'field' => 'gender',
                'label' => 'Gender',
                'rules' => 'required',
                'errors' => array(
                  'required' => '%s is required',
                ),
            ),
            array(
                'field' => 'birthdate',
                'label' => 'Birth Date',
                'rules' => 'required',
                'errors' => array(
                  'required' => '%s is required',
                ),
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|valid_email|is_unique[test.email]',
                'errors' => array(
                  'required' => '%s is required',
                    'valid_email' => '%s should be valid email',
                    'is_unique' => '%s already registered',
                ),
            ),
                        array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'trim|required|min_length[8]',
                'errors' => array(
                  'required' => '%s is required',
                    'min_length' => 'min length of %s should be 8',
                ),
            ),
                        array(
                'field' => 'passconf',
                'label' => 'Confirmation Password',
                'rules' => 'trim|required|matches[password]',
                'errors' => array(
                  'required' => '%s is required',
                    'matches' => 'does not match with password',
                ),
            ),
        );
        
        $this->form_validation->set_rules($config);
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templetes/header');
            $this->load->view('pages/index');
            $this->load->view('templetes/footer');
        } else {
            $this->load->model('register');
            
        }
        $this->benchmark->mark('code_end');    
    }
}
