<?php

class Home extends CI_Controller {

    public function index() {
        $this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<label class="error">','</label>');

        $this->form_validation->set_rules('firstname', 'First Name', 'trim|required|alpha');
        $this->form_validation->set_rules('lastname', 'Last Name', 'trim|required|alpha');
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]alpha_numeric');
        $this->form_validation->set_rules('gender','Gender','required');
        $this->form_validation->set_rules('birthdate', 'Birth Date', 'required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templetes/header');
            $this->load->view('pages/index');
            $this->load->view('templetes/footer');
        } else {
            $data = array();
            
            $this->load->view('pages/formsuccess',$data);
        }
    }
}
