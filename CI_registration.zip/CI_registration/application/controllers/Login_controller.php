<?php

class Login_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('login_model');
    }

    function index() {
        $this->load->view('templetes/header');

        $this->form_validation->set_error_delimiters('<label class="error">', '</label>');

        $config = array(
            array(
                'field' => 'loginid',
                'label' => 'User Name/Email',
                'rules' => 'required|min_length[6]|alpha_numeric',
                'errors' => array(
                    'required' => '%s is required',
                    'alpha_numeric' => '%s should contain only alphabets and numbers',
                    'min_length' => 'min length of %s shoul be 6',
                ),
            ),
            array(
                'field' => 'loginpass',
                'label' => 'Password',
                'rules' => 'required|min_length[8]',
                'errors' => array(
                    'required' => '%s is required',
                    'min_length' => 'min length of %s shoul be 8',
                ),
            ),
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE) {

            if (isset($this->session->userdata['logged_in'])) {
                $this->load->view('pages/home');
            } else {
                $msg = array('statusmsg' => '');

                $this->load->view('pages/login_form', $msg);
            }
        } else {
            $logindata = array(
                'loginid' => $this->input->post('loginid'),
                'loginpass' => $this->input->post('loginpass')
            );
            $result = $this->login_model->login($logindata);

            if ($result == TRUE) {
                $loginid = $this->input->post('loginid');

                $logindetails = $this->login_model->login_details($loginid);

                if ($logindetails != FALSE) {
                    $session_data = array(
                        'firstname' => $logindetails[0]['firstname'],
                        'lastname' => $logindetails[0]['lastname'],
                        'username' => $logindetails[0]['username'],
                        'birthdate' => $logindetails[0]['birthdate'],
                        'gender' => $logindetails[0]['gender'],
                        'email' => $logindetails[0]['email'],
                    );
                    $this->session->set_userdata('logged_in', $session_data);
                    $this->load->view('pages/home');
                }
            } else {
                $msg = array('statusmsg' => 'Username Or Password Invalid!!!');

                $this->load->view('pages/login_form', $msg);
            }
        }
        $this->load->view('templetes/footer');
    }

    function logout() {
        $sess_array = array(
            'username' => ''
        );
        $this->session->unset_userdata('logged_in', $sess_array);
        $msg['statusmsg'] = 'Successfully Logout';
        $this->load->view('templetes/header');
        $this->load->view('pages/login_form', $msg);
        $this->load->view('templetes/footer');
    }

}
