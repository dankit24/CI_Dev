<?php

class Login extends CI_Controller{
    function index(){
        $this->load->helper(array('url','form'));
        $this->load->library('form_validation');
        
        $this->form_validation->set_error_delimiters('<label class="error">','</label>');
        
        $this->form_validation->set_rules('loginid','Username/Email','required|min_length[6]|alpha_numeric');
        $this->form_validation->set_rules('loginpass','Password','required|min_length[8]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->load->view('templetes/header');
            $this->load->view('pages/index');
            $this->load->view('templetes/footer');
        }
        else
        {
            $this->load->model('login_model');
        }
    }
}

