<?php

class Login extends CI_Controller{
    function index(){
        $this->load->helper(array('url','form'));
        $this->load->library('form_validation');
        
        $this->form_validation->set_error_delimiters('<label class="error">','</label>');
        
                $config = array(
            array(
                'field' => 'loginid',
                'label' => 'User Name/Email',
                'rules' => 'required|min_length[6]|alpha_numeric',
                'errors' => array(
                  'required' => '%s is required',
                    'alpha_numeric' => '%s should contain only alphabets and numbers',
                    'min_length' => 'min length of %s shoul be 6',
                ),
            ),
            array(
                'field' => 'loginpass',
                'label' => 'Password',
                'rules' => 'required|min_length[8]',
                'errors' => array(
                  'required' => '%s is required',
                    'min_length' => 'min length of %s shoul be 8',
                ),
            ),
        );
        
        $this->form_validation->set_rules($config);
        
        if($this->form_validation->run() == FALSE)
        {
            $this->load->view('templetes/header');
            $this->load->view('pages/index');
            $this->load->view('templetes/footer');
        }
        else
        {
            $this->load->model('login_model');
        }
    }
}

