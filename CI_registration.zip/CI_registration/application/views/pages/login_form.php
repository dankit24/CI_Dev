<?php    
if (isset($this->session->userdata['logged_in'])) {
        header("location: ".base_url()."login_controller");
    }
    ?>
<section class="logintable">
    <?php echo form_open('login_controller'); ?>
    <table cellspacing="10" align="center">
        <caption><h1 style="color: black;">Log In...</h1><label class="error"><?php echo $statusmsg;?></label></caption>
        <tr>
            <td>
                <input type="text" name="loginid" value="<?php echo set_value('loginid') ?>" placeholder="Username/Email">
            </td>
            <td><?php echo form_error('loginid'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="password" name="loginpass" value="<?php echo set_value('loginpass') ?>" placeholder="Password">
            </td>
            <td><?php echo form_error('loginpass'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="submit" value="log In" style="width: auto;">
            </td>
        </tr>
        <tr>
            <td>
                <p><a style="color: white;" href='<?php base_url()?>register_controller'>Click Here</a> To register!!!</p>
            </td>
        </tr>
    </table>
    
    <?php form_close() ?>
</section>