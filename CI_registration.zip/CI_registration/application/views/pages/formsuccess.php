<html>
    <head>
        <title>My Form</title>
    </head>
    <body>

        <h3><?php echo $status;?></h3>
        
        <p><?php echo anchor('home', 'Try it again'); ?></p>
        <p>First Name: <?php echo $firstname;?></p>
        <p>Last Name: <?php echo $lastname;?></p>
        <p>User Name: <?php echo $username;?></p>
        <p>Birth Date: <?php echo $birthdate;?></p>
        <p>Gender: <?php if($gender == 'm')echo 'male';else echo 'Female';?></p>
        <p>Email: <?php echo $email;?></p>
        <p>Password: <?php echo $password;?></p>
        <p>Confirm Password:<?php echo $passconf;?></p>
    </body>
</html>