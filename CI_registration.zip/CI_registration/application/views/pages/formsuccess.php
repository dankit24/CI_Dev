<html>
    <head>
        <title>My Form</title>
    </head>
    <body>

        <h3>your form was successfully submitted</h3>
        
        <p><?php echo anchor('home', 'Try it again'); ?></p>

    </body>
</html>