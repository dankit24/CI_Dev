<section class="register">
<div>
<?php echo form_open('home');?>
<table cellspacing="10">
    <tr>
        <td>
            <input type="text" name="firstname" value="<?php echo set_value('firstname');?>" placeholder="First Name" />
            <label><?php echo form_error('firstname'); ?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="text" name="lastname" value="<?php echo set_value('lastname');?>" placeholder="Last Name" />
            <label><?php echo form_error('lastname'); ?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="text" name="username" value="<?php echo set_value('username');?>" placeholder="User Name" />
            <label><?php echo form_error('username'); ?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="date" name="birthdate" value="<?php echo set_value('birthdate');?>" placeholder="Birth Date" />
            <label><?php echo form_error('birthdate'); ?></label>
        </td>
    </tr>
    <tr>
        <td>
            Male<input type="radio" name="gender" value="1" style="width: auto;" <?php set_radio('gender','1',TRUE)?> />
            Female<input type="radio" name="gender" value="0" style="width: auto;" <?php set_radio('gender','0')?> />
            <label><?php echo form_error('gender');?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="email" name="email" value="<?php echo set_value('email');?>" placeholder="E-Mail" />
            <label><?php echo form_error('email');?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="password" name="password" value="<?php echo set_value('password');?>" placeholder="Password" />
            <label><?php echo form_error('password');?></label>
        </td>
    </tr>
    <tr>
        <td>
            <input type="password" name="passconf" value="<?php echo set_value('passconf');?>" placeholder="Confirm Password" />
            <label><?php echo form_error('passconf');?></label>
        </td>
    </tr>
    <tr><td>
            <div><input type="submit" value="Submit" style="width: auto;"></div>
        </td></tr>
</table>
</form>
</div>
</section>