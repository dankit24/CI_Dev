<section class="logintable">
    <?php echo form_open('login'); ?>
    <table cellspacing="10">
        <caption><h1 style="color: black;">Log In...</h1></caption>
        <tr>
            <td>
                <input type="text" name="loginid" value="<?php echo set_value('loginid') ?>" placeholder="Username/Email">
            </td>
            <td><?php echo form_error('loginid'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="password" name="loginpass" value="<?php echo set_value('loginpass') ?>" placeholder="Password">
            </td>
            <td><?php echo form_error('loginpass'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="submit" value="log In" style="width: auto;">
            </td>
        </tr>
    </table>
    <?php form_close() ?>
</form>
</section>

<section class="registertable">
        <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>

<section>
            <?php echo form_open('home'); ?>
        <table cellspacing="10">
            <caption><h1 style="color: black;">Register Now!!!</h1></caption>
            <tr>
                <td>
                    <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
                </td>
                <td><?php echo form_error('firstname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
                </td>
                <td><?php echo form_error('lastname'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
                </td>
                <td><?php echo form_error('username'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="date" name="birthdate" value="<?php echo set_value('birthdate'); ?>" placeholder="Birth Date" />
                </td>
                <td><?php echo form_error('birthdate'); ?></td>
            </tr>
            <tr>
                <td>
                    Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                    Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
                </td>
                <td><?php echo form_error('gender'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
                </td>
                <td><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
                </td>
                <td><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td>
                    <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
                </td>
                <td><?php echo form_error('passconf'); ?></td>
            </tr>
            <tr><td>
                    <div><input type="submit" value="Submit" style="width: auto;"></div>
                </td></tr>
        </table>
        <?php form_close() ?>
        </form>
</section>
