<section>
    <?php
    if(isset($this->session->userdata['logged_in']))
    {
        $firstname = ($this->session->userdata['logged_in']['firstname']);
        $lastname = ($this->session->userdata['logged_in']['lastname']);
        $username = ($this->session->userdata['logged_in']['username']);
        $birthdate = ($this->session->userdata['logged_in']['birthdate']);
        $gender = ($this->session->userdata['logged_in']['gender']);
        $email = ($this->session->userdata['logged_in']['email']);
    }
    else{
        header('location: login');
    }
    ?>
    
    <div align="center">
        <h1><?php echo 'Welcome '.$firstname.' '.$lastname;?></h1>
        <table>
            <tr>
                <td>First Name</td>
                <td><?php echo $firstname;?></td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><?php echo $lastname;?></td>
            </tr>
            <tr>
                <td>User Name</td>
                <td><?php echo $username;?></td>
            </tr>
            <tr>
                <td>Birth Date</td>
                <td><?php echo $birthdate;?></td>
            </tr>
            <tr>
                <td>Gender</td>
                <td><?php if($gender == 1)echo 'Male';else echo 'Female';?></td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td><?php echo $email;?></td>
            </tr>
            <tr>
                <td>
                    <input type="button" value="Logout" onclick="location = '<?php base_url()?>Login_controller/logout'">
                </td>
            </tr>
        </table>
    </div>
</section>
