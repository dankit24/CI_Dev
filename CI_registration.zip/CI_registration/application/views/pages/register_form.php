<?php
if (isset($this->session->userdata['logged_in'])) {
    header("location: ".base_url()."/login_controller");
}
?>

<?php date_default_timezone_set('asia/kolkata'); ?>
<section class="registertable">
    <?php echo form_open('register_controller'); ?>
    <table cellspacing="10" align="center">
        <caption><h1 style="color: black;">Register Now!!!</h1><label class="error"><?php echo $statusmsg; ?></label></caption>
        <tr>
            <td>
                <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" placeholder="First Name" />
            </td>
            <td><?php echo form_error('firstname'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name" />
            </td>
            <td><?php echo form_error('lastname'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name" />
            </td>
            <td><?php echo form_error('username'); ?></td>
        </tr>
        <tr>
            <td>
                <input placeholder="Birth Date" type="text" name="birthdate" onfocus="(this.type = 'date')" onblur="(this.type = 'text')" value="<?php echo set_value('birthdate'); ?>" min="1818-01-01" max="<?php echo date('Y-m-d') ?>"/>
            </td>
            <td><?php echo form_error('birthdate'); ?></td>
        </tr>
        <tr>
            <td>
                Male<input type="radio" name="gender" value='1' <?php echo set_radio('gender', '1'); ?> style="width: auto;" />
                Female<input type="radio" name="gender" value="0" <?php echo set_radio('gender', '0'); ?> style="width: auto;" />
            </td>
            <td><?php echo form_error('gender'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="text" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-Mail" />
            </td>
            <td><?php echo form_error('email'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password" />
            </td>
            <td><?php echo form_error('password'); ?></td>
        </tr>
        <tr>
            <td>
                <input type="password" name="passconf" value="<?php echo set_value('passconf'); ?>" placeholder="Confirm Password" />
            </td>
            <td><?php echo form_error('passconf'); ?></td>
        </tr>
        <tr><td>
                <div><input type="submit" value="Submit" style="width: auto;"></div>
            </td></tr>
        <tr>
            <td>
                <p>Already Registered, <a style="color: white;" href='<?php base_url() ?>/login_controller'>Log In!!!</a></p>
            </td>
        </tr>
    </table>
    <?php form_close() ?>
</section>