<nav>
    <ul class="footer">
        <li><a href="<?php site_url('home')?>">Top</a></li>
        <li><a href="http://google.com"><img src='<?php base_url() ?>/assets/images/facebook-logo-button.png' alt="fb" width="30" height="30"></a></li>
        <li><a href="http://github.com"><img src='<?php base_url() ?>/assets/images/google-plus-logo-button.png' alt="gplus" width="30" height="30"></a></li>
        <li><a href="http://w3schools.com"><img src='<?php base_url() ?>/assets/images/twitter-logo-button.png' alt="twitter" width="30" height="30"></a></li>
        <li><a href="http://tutorialspoint.com"><img src='<?php base_url() ?>/assets/images/linkedin-logo-button.png' alt="li" width="30" height="30"></a></li>
    </ul>
</nav>
</body>
</html>

