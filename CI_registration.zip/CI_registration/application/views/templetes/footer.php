<nav class="footer">
    <ul class="footer">
        <li class="fl1"><a href="">Home</a></li>
        <li class="fl2"><img src='<?php base_url() ?>/assets/images/facebook-logo-button.png' alt="fb" width="30" height="30"></li>
        <li class="fl3"><img src='<?php base_url() ?>/assets/images/google-plus-logo-button.png' alt="gplus" width="30" height="30"></li>
        <li class="fl4"><img src='<?php base_url() ?>/assets/images/twitter-logo-button.png' alt="twitter" width="30" height="30"></li>
        <li class="fl5"><img src='<?php base_url() ?>/assets/images/linkedin-logo-button.png' alt="li" width="30" height="30"></li>
    </ul>
</nav>
</body>
</html>
