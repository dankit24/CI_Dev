<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="<?php base_url() ?>/assets/css/style.css">
    </head>
    <body>
        <nav>
            <ul>
                <li>URS</li>
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact Us</a></li>
            </ul>
        </nav>
