<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="<?php base_url() ?>/assets/css/style.css">
    </head>
    <body>
        <header>
        <nav>
            <ul>
                <li>URS</li>
                <li><a href="">Home</a></li>
                <li><a href="">Register</a></li>
                <li><a href="<?php base_url()?>/application/views/templetes/footer.php">Contact Us</a></li>
            </ul>
        </nav>
        </header>
