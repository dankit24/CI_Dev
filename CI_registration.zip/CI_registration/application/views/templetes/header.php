<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="<?php base_url() ?>/assets/css/style.css">
    </head>
    <body>
        <nav class="header">
            <ul>
                <li><a href="<?php site_url('home')?>">Home</a></li>
                <li><a href="">Home</a></li>
                <li><a href="">Register</a></li>
                <li><a href="">Contact Us</a></li>
            </ul>
        </nav>
