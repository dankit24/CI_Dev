    <?php
    if(isset($this->session->userdata['logged_in']))
    {
        $Home = ($this->session->userdata['logged_in']['username']);
    }
    else{
        $Home = 'Home';
    }
    ?>
<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="<?php base_url() ?>/assets/css/style.css">
    </head>
    <body>
        <nav class="header">
            <ul>
                <li><a href="<?php base_url()?>/login_controller"><?php echo $Home;?></a></li>
                <li><a href="<?php base_url()?>/login_controller">Home</a></li>
                <li><a href="<?php base_url()?>/register_controller">Register</a></li>
                <li><a href="">Contact Us</a></li>
            </ul>
        </nav>
