<?php
class register extends CI_Model{
    function __construct() {
        parent::__construct();
        
        $this->load->helper(array('url'));
        $status =array(
            'status' => 'Your form was successfully submitted'
        );
        
        $data = array(
            'firstname' => $this->input->post('firstname'),
            'lastname' => $this->input->post('lastname'),
            'username' => $this->input->post('username'),
            'birthdate' => $this->input->post('birthdate'),
            'gender' => $this->input->post('gender'),
            'email' => $this->input->post('email'),
            'password' => password_hash($this->input->post('password'),PASSWORD_BCRYPT)
        );

        $status += $data;
        
            $this->load->database();
            if($this->db->insert('test',$data))
            {
            $this->load->view('templetes/header');
            $this->load->view('pages/formsuccess',$status);
            $this->load->view('templetes/footer');
            }
            else {
            $data = array(
                'status' => 'error storing data to database'
            );
            $this->load->view('templetes/header');
            $this->load->view('pages/formsuccess',$status);
            $this->load->view('templetes/footer');
            }
    }
}
