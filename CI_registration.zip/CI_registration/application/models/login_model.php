<?php
class login_model extends CI_Model{
function __construct()
    {
    parent::__construct();
        $this->load->helper('url');
        
        $this->load->database();
        
        $loginid = $this->input->post('loginid');
        $password = $this->input->post('loginpass');
        
        $query = $this->db->get_where('test',array('username' => $loginid));
        $data = $query->row_array();
        
        $status = array('status' => 'Login Successful '.$data['firstname'].' '.$data['lastname']);
        
        
        
        if(password_verify($password, $data['password']))
        {
            $status += $data;
            $this->load->view('templetes/header');
            $this->load->view('pages/formsuccess',$status);
            $this->load->view('templetes/footer');
        }
        else
        {
            $this->load->view('templetes/header');
            $this->load->view('pages/index');
            $this->load->view('templetes/footer');
        }
    }
}
