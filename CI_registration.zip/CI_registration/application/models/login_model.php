<?php
class login_model extends CI_Model{
function __construct()
    {
    parent::__construct();
        $this->load->helper('url');
        
        $this->load->database();
    }
    function login($logindata){
        
        $query = $this->db->get_where('test',array('username' => $logindata['loginid']));
        
        $database = $query->row_array();
        
        if(password_verify($logindata['loginpass'], $database['password']))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    function login_details($loginid){
        $query = $this->db->get_where('test',array('username' => $loginid));
        $database = $query->result_array();

        if($query->num_rows() == 1)
        {
            return $database;
        }
        else
        {
            return FALSE;
        }
    }
}
