<?php
class login_model extends CI_Model{
function __construct()
    {
    parent::__construct();
        $this->load->helper('url');
        
        $this->load->database();
    }
    function login($logindata){
        
        $condition = "username ="."'".$logindata['loginid']."'";
        $this->db->select('password');
        $this->db->from('test');
        $this->db->where($condition);
        $query = $this->db->get();
        
        if($query->num_rows() == 1)
        {
        $database = $query->row_array();

        if(password_verify($logindata['loginpass'], $database['password']))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        }
        else
            {
            return 'une';
        }
    }
    
    function login_details($loginid){
        $query = $this->db->get_where('test',array('username' => $loginid));
        $database = $query->result_array();

        if($query->num_rows() == 1)
        {
            return $database;
        }
        else
        {
            return FALSE;
        }
    }
}
if(TRUE)
    {}
else if(TRUE)
    {}
else
    {}