<?php

class register_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
    }

    function register($data) {
        $result = $this->db->insert('test', $data);
        if ($result == TRUE) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}
