<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Paging extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
 
        // load Pagination library
        $this->load->library('pagination');
         
        // load URL helper
        $this->load->helper('url');
    } 
    public function index() 
    {
        $this->output->enable_profiler(TRUE);
        $this->benchmark->mark('start');
        
        // load db and model
        $this->load->database();
        $this->load->model('Users');
 
        // init params
        $params = array();
        $limit_per_page = 6;
        $start_index = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        print_r($start_index);
        $total_records = $this->Users->get_total();
        print_r($total_records);
 
        if ($total_records > 0) 
        {
            // get current page records
            $params["results"] = $this->Users->get_current_page_records($limit_per_page, $start_index);
             
            $config['base_url'] = base_url() . 'paging/index';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 3;
            
            // custom paging configuration

            $config['reuse_query_string'] = TRUE;
             
            $config['full_tag_open'] = '<table align="center" class="pagination">';
            $config['full_tag_close'] = '</table><tr>';
             
            $config['first_link'] = 'First Page';
            $config['first_tag_open'] = '<td class="firstlink">';
            $config['first_tag_close'] = '</td>';
             
            $config['last_link'] = 'Last Page';
            $config['last_tag_open'] = '<td class="lastlink">';
            $config['last_tag_close'] = '</td>';
             
            $config['next_link'] = 'Next Page';
            $config['next_tag_open'] = '<td class="nextlink">';
            $config['next_tag_close'] = '</td>';
 
            $config['prev_link'] = 'Prev Page';
            $config['prev_tag_open'] = '<td class="prevlink">';
            $config['prev_tag_close'] = '</td>';
 
            $config['cur_tag_open'] = '<td class="curlink">';
            $config['cur_tag_close'] = '</td>';
 
            $config['num_tag_open'] = '<td class="numlink">';
            $config['num_tag_close'] = '</td>';
             
            $this->pagination->initialize($config);
             
            // build paging links
            $params["links"] = $this->pagination->create_links();
        }
         
        $this->load->view('user_listing', $params);
        $this->benchmark->mark('end');
    }
}