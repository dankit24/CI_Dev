<?php

class Test extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('unit_test');
    }

    function index() {
        $test = 1.8 + 0.2;

        $expected_result = 2.0;

        $test_name = 'Adds one plus one';

        //$this->unit->set_test_items(array('test_name', 'result'));
        $str = '<table border="0" cellpadding="4" cellspacing="1">
{rows}
        <tr>
                <td>{item}</td>
                <td>{result}</td>
        </tr>
{/rows}
</table>';

        $this->unit->set_template($str);

        $this->unit->use_strict(TRUE);
        echo $this->unit->run($test, $expected_result, $test_name);
        echo '</br>';
        print_r($this->unit->result());
    }

}
