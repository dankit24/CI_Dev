<html>
    <head>
        <title>Shoping Cart</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
    </head>
    <body>
        <section class="cart">
            <nav class="carthead">
                <ul align="center">
                    <li><a href=""><h1>Shopping Cart</h1></a></li>
                    <li><input type="button" value="Empty Cart" name="empty"></li>
                </ul>
            </nav>
            <p align="center" style="color: green;"><?php echo $succstatus; ?></p>
            <p align="center" style="color: red;"><?php echo $failstatus; ?></p>
            <div class="usercart">
                <table>
                    <thead>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                    </thead>
                    <tbody align="center">
                        <tr>
                        </tr>
                    </tbody>
                </table>
                <p>Grand Total: $0</p>
            </div>
        </section>

        <section class="cartlist">
            <div class="cartsplit">
                <p align="center">Product Catalog</p>
            </div>

            <div class="cartitems">

                <p align="center"><img src="<?php echo $product1['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product1['name'] ?></p>
                <p align="center">$<?php echo $product1['price'] ?></p>

                <form action="<?php FCPATH ?>/ShoppingCart?p=product1" method="post">
                    <table align="center">
                        <tr>
                            <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                            <td><input type="submit" value="add to cart"></td>
                        </tr>
                    </table>
                </form>
            </div>

            <div class="cartitems">
                <p align="center"><img src="<?php echo $product2['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product2['name'] ?></p>
                <p align="center">$<?php echo $product2['price'] ?></p>

                <form action="<?php FCPATH ?>/ShoppingCart?p=product2" method="post">
                    <table align="center">
                        <tr>
                            <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                            <td><input type="submit" value="add to cart"></td>
                        </tr>
                    </table>
                </form>
            </div>

            <div class="cartitems">

                <p align="center"><img src="<?php echo $product3['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product3['name'] ?></p>
                <p align="center">$<?php echo $product3['price'] ?></p>

                <form action="<?php FCPATH ?>/ShoppingCart?p=product3" method="post">
                    <table align="center">
                        <tr>
                            <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                            <td><input type="submit" value="add to cart"></td>
                        </tr>
                    </table>
                </form>
            </div>

            <div class="cartitems">
                <p align="center"><img src="<?php echo $product4['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product4['name'] ?></p>
                <p align="center">$<?php echo $product4['price'] ?></p>

                <form action="<?php FCPATH ?>/ShoppingCart?p=product4" method="post">
                    <table align="center">
                        <tr>
                            <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                            <td><input type="submit" value="add to cart"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </section>
    </body>
</html>
