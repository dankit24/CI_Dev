<?php

class cartstatus extends CI_Model{
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }
    public function addtocart($data,$products){
        $products =$products[$data['product']];
        $products['qty'] = $data['qty'];

        $this->session->set_userdata('cart', $products);
        $getproduct = $this->session->get_userdata();
        print_r($getproduct);
        echo '</br>';
        echo '</br>';
        echo '</br>';
        print_r(json_encode($getproduct));
    }
}
