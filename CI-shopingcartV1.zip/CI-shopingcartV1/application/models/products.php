<?php

class products extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
    }
    public function loadproducts(){
        $products = array(
            'product1' => array('name' => 'Beats Headphones', 'price' => '1800', 'code' => 'BWH01', 'image' => '../../assets/cartitems/product1.png', 'qty' => '0'),
            'product2' => array('name' => 'Apple Smartwatch', 'price' => '2000', 'code' => 'ASW02', 'image' => '../../assets/cartitems/product2.jpg', 'qty' => '0'),
            'product3' => array('name' => 'FitBit fitness band', 'price' => '800', 'code' => 'FBFB3', 'image' => '../../assets/cartitems/product3.jpg', 'qty' => '0'),
            'product4' => array('name' => 'DSLR Camera', 'price' => '2300', 'code' => 'DSLR4', 'image' => '../../assets/cartitems/product4.jpg', 'qty' => '0')
        );
        return $products;
    }
}