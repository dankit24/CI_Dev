<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
class Shoppingcart extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->library(array('form_validation'));
        $this->load->helper(array('url','form'));
        $this->load->model('products');
        $this->load->model('cartstatus');
    }
    public function index(){
        $this->output->enable_profiler();
        $products = $this->products->loadproducts();
        $config = array(
            array('field'=>'qty',
                'label'=>'Quantity',
                'rules'=>'required'),
        );
        
        $this->form_validation->set_rules($config);
        if($this->form_validation->run()== FALSE)
        {
        $this->load->view('home',$products);
        }
        else{
            $msg = array('succstatus'=>'Product successfuly added to cart');
            $data = array('product'=>$_GET['p'],'qty'=>$_POST['qty']);
            $status = $this->cartstatus->addtocart($data,$products);
            $this->load->view('home',$msg);
        }
    }
}