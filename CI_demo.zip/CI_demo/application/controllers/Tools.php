<?php

class Tools extends CI_Controller {

    public function message($to = 'World') {
        $this->load->driver('cache', array('adapter' => 'file'));
        $this->load->library('user_agent');

        if (!$foo = $this->cache->get('foo')) {
            echo 'Saving to the cache!<br />';
            $foo = 'foobarbaz!';

            // Save into the cache for 5 minutes
            $this->cache->save('foo', $foo, 60);
        }

        echo $foo;

        $prefs['template'] = array(
            'table_open' => '<table class="calendar">',
            'cal_cell_start' => '<td class="day">',
            'cal_cell_start_today' => '<td class="today">'
        );

        $this->load->library('calendar', $prefs);

        echo $this->calendar->generate();
        echo '</br>';
        print_r($this->calendar->adjust_date(2, 2014));
        echo '</br>';
        echo $this->calendar->get_total_days(2, 2014);
        echo '</br>';
        if ($this->agent->is_browser()) {
            $agent = $this->agent->browser() . ' ' . $this->agent->version();
        } elseif ($this->agent->is_robot()) {
            $agent = $this->agent->robot();
        } elseif ($this->agent->is_mobile()) {
            $agent = $this->agent->mobile();
        } else {
            $agent = 'Unidentified User Agent';
        }
        echo '</br>';
        echo $agent;
        echo '</br>';
        echo $this->agent->platform(); // Platform info (Windows, Linux, Mac, etc.)
    }

}
