<?php

class Tools extends CI_Controller {

    public function message($to = 'World') {
        $this->load->driver('cache', array('adapter' => 'apc'));

        if (!$foo = $this->cache->get('foo')) {
            echo 'Saving to the cache!<br />';
            $foo = 'foobarbaz!';

            // Save into the cache for 5 minutes
            $this->cache->save('foo', $foo, 60);
        }

        echo $foo;

$prefs['template'] = array(
        'table_open'           => '<table class="calendar">',
        'cal_cell_start'       => '<td class="day">',
        'cal_cell_start_today' => '<td class="today">'
);

$this->load->library('calendar', $prefs);

echo $this->calendar->generate();

print_r($this->calendar->adjust_date(77, 2014));

echo $this->calendar->get_total_days(5, 2012);
        }

}
