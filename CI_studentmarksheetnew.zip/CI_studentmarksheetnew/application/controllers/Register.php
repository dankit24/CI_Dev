<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation'));
        $this->load->model('register_model');
    }

    function index() {
        $this->form_validation->set_error_delimiters('<label class="error">', '</label>');
        $config = array(
            array(
                'field' => 'firstName',
                'label' => 'First Name',
                'rules' => 'required|alpha',
                'errors' => array('required' => '%s is Required!!!',
                                  'alpha' => '%s should contain only alphabets!!!'),
            ),
            array(
                'field' => 'lastName',
                'label' => 'Last Name',
                'rules' => 'required|alpha',
                'errors' => array('required' => '%s is Required!!!',
                                 'alpha' => '%s should contain only alphabets!!!'),
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required|valid_email|is_unique[user.email ]',
                'errors' => array('required' => '%s is Required!!!',
                                 'valid_email' => '%s is not valid email!!!',
                                 'is_unique' => '%s is already registerd!!!'),
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'required|min_length[6]',
                'errors' => array('required' => '%s is Required!!!',
                                 'min_length' => '%s should be atleast 8 character long!!!'),
            ),
            array(
                'field' => 'confirmPassword',
                'label' => 'Password Confirmation',
                'rules' => 'required|min_length[6]|matches[password]',
                'errors' => array('required' => '%s is Required!!!',
                                 'min_length' => 'should be atleast 8 character long!!!',
                                 'matches' => "Entered password doesnot match."),
            ),
        );
        $this->form_validation->set_rules($config);
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('register');
        } else {
            $data = array(
                'first_name' => $this->input->post('firstName'),
                'last_name' => $this->input->post('lastName'),
                'email' => $this->input->post('email'),
                'profile_picture' => '../../assets/uploads/default.png',
                'user_role' => $this->input->post('userRole'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            );
            $result = $this->register_model->register($data);
            if($result === TRUE){
                echo 'data stored';
            }
            else{
                echo 'data not stored';
            }
        }
    }

}
