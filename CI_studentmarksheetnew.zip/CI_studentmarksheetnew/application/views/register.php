<html>
    <head>
        <title>Register</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
    </head>
    <body>
    <center><h1>Student Registration</h1></center>
    <?php echo form_open_multipart('register'); ?>
    <center><table>
        <tr>
            <td>First Name</td>
            <td><input type="text" name="firstName" value="<?php echo set_value('firstName'); ?>"><?php echo form_error('firstName'); ?></td>
        </tr>
        <tr>
            <td>Last Name</td><td><input type="text" name="lastName" value="<?php echo set_value('lastName'); ?>"><?php echo form_error('lastName'); ?></td>
        </tr>
        <tr>
            <td>email</td><td><input type="text" name="email" value="<?php echo set_value('email'); ?>"><?php echo form_error('email'); ?></td>
        </tr>
        <tr>
            <td>profile</td><td><input type="file" name="profilePicture" value="<?php echo set_value('profilePicture'); ?>"></td>
        </tr>
        <tr hidden>
            <td>User Role</td><td><input type="text" name="userRole" value="0"></td>
        </tr>
        <tr>
            <td>Password</td><td><input type="password" name="password" value="<?php echo set_value('password'); ?>"><?php echo form_error('password'); ?></td>
        </tr>
        <tr>
            <td>Confirm Password</td><td><input type="password" name="confirmPassword" value="<?php echo set_value('confirmPassword'); ?>"><?php echo form_error('confirmPassword'); ?></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" name="Submit"></td>
        </tr>
    </table></center>
    <?php echo form_close(); ?>
</body>
</html>