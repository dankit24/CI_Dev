<html>
    <head>
        <title>Register</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
    </head>
    <body>
    <center><h1>Student Login</h1></center>
    <?php echo form_open_multipart('login'); ?>
    <center><table>
            <tr>
                <td>Email</td><td><input type="text" name="email" value="<?php echo set_value('email'); ?>"><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>Password</td><td><input type="password" name="password" value="<?php echo set_value('password'); ?>"><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="Submit"></td>
            </tr>
        </table></center>
    <?php echo form_close(); ?>
</body>
</html>