<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class login_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
    }

    function login($data) {

        $this->db->select('password');
        $this->db->from('user');
        $this->db->where('email', $data['email']);
        $result = $this->db->get();
        $hash_password = $result->row_array()['password'];

        if (password_verify($data['password'], $hash_password)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}
