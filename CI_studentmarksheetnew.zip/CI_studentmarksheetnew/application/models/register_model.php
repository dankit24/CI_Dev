<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */
class register_model extends CI_Model{
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    function register($data){
        $result = $this->db->insert('user',$data);
        if($result === TRUE){
            return TRUE;
        }
        else{
            return FALSE;
        }
    }
}

