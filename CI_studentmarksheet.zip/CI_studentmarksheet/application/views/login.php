<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php FCPATH?>/assets/js/validation.js"></script>
    </head>
    <body>
    <center><h1>Student Login</h1></center>
    <?php echo form_open('login'); ?>
    <center><table>
            <tr>
                <td>Email</td><td><input type="text" id="email" name="email" value="<?php echo set_value('email'); ?>"><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>Password</td><td><input type="password" id="password" name="password" value="<?php echo set_value('password'); ?>"><?php echo form_error('password'); ?></td>
            </tr>
            <tr>
                <td><input type="submit" name="Submit" id="loginSubmit"></td>
            </tr>
            <tr>
                <td>Not Register Yet?<a href="<?php echo base_url('register');?>">Click Here!</a></td>
            </tr>
        </table></center>
    <?php echo form_close(); ?>
</body>
</html>