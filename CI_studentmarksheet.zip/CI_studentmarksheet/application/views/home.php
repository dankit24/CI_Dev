<html>
    <head>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php base_url(); ?>/assets/css/style.css">
        <script src="<?php base_url() ?>/assets/js/jquery-3.2.1.min.js"></script>
        <script src="<?php base_url() ?>/assets/js/home.js"></script>
    </head>
    <body class="body">
    <center><nav class="menu">
            <ul>
                <a class="tab-1" href="#tab-1"><li>Add New Student</li></a>
                <a class="tab-2" href="#tab-2"><li>Add Student Marks</li></a>
                <a class="tab-3" href="#tab-3"><li>View Student Marks</li></a>
            </ul>
        </nav></center>

    <center><section id="tab-1" hidden>
            <div>
                <table>
                    <tr>
                        <td><input type="text" name="fname" id="fname" placeholder="First Name"><?php set_value('fname') ?></td>
                        <td><input type="text" name="lname" id="lname" placeholder="Last Name"><?php set_value('lname') ?></td>
                    </tr>
                    <tr>
                        <td id='msg1'><?php echo form_error('fname'); ?></td>
                        <td id='msg2'><?php echo form_error('lname'); ?></td>
                    </tr>
                </table>
                <center><input type="button" id='addstudent' value="Add"></center>
                <div id='studentinfo'>
                    <center><table cellspacing="10">
                            <thead>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Action</th>
                            </thead>
                            <tbody><tr></tr></tbody>
                        </table></center>
                </div>
            </div>
        </section></center>

    <center><section id="tab-2" hidden>
            <div>

                <cener><table id="marksinput">
                    <tr>
                        <td colspan="5"><select id="studentname" style="width: 100%;">
                                <option>Ankit desai</option>
                            <option>Ankit desai</option>
                            <option>Ankit desai</option></select>
                        </td>
                    </tr>
                    <tr>
                        <td>Subject</td>
                        <td>Practical Mark</td>
                        <td>Viva Mark</td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="sub1" class="sub1" id="sub1">
                            <label for="sub1" class="labelsub1">PHP</label></td>
                    <td><input type="text" name="prac1" id="prac1" size="10" disabled></td>
                    <td><input type="text" name="viva1" id="viva1" size="10" disabled></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="sub2" class="sub2" id="sub2">
                            <label for="sub2" class="labelsub2">MySql</label></td>
                        <td><input type="text" name="prac2" id="prac2" size="10" disabled></td>
                        <td><input type="text" name="viva2" id="viva2" size="10" disabled></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="sub3" class="sub3" id="sub3">
                            <label for="sub3" class="labelsub3">Javascript</label></td>
                        <td><input type="text" name="prac3" id="prac3" size="10" disabled></td>
                        <td><input type="text" name="viva3" id="viva3" size="10" disabled></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="sub4" class="sub4" id="sub4">
                            <label for="sub4" class="labelsub4">Jquery</label></td>
                        <td><input type="text" name="prac4" id="prac4" size="10" disabled></td>
                        <td><input type="text" name="viva4" id="viva4" size="10" disabled></td>
                    </tr>
                    <tr>
                        <td colspan="5"><input type="button" id="addmarks" value="Submit Marks" style="width: 100%;"></td>
                    </tr>
                    </table></cener>
                
                <table id="marksoverview">
                    <thead>
                    <th>Student Name</th>
                    <th>Subject</th>
                    <th>Practical Marks</th>
                    <th>Viva Marks</th>
                    <th>Total</th>
                    </thead>
                </table>

            </div>
        </section></center>

    <center><section id="tab-3" hidden>
            <p>Hello 3</p>
        </section></center>
</body>
</html>