<html>
    <head>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php base_url(); ?>/assets/css/style.css">
        <script src="<?php base_url() ?>/assets/js/jquery-3.2.1.min.js"></script>
        <script src="<?php base_url() ?>/assets/js/home.js"></script>
    </head>
    <body class="body">
    <center><nav class="menu">
            <ul>
                <a class="tab-1" href="#tab-1"><li>Add New Student</li></a>
                <a class="tab-2" href="#tab-2"><li>Add Student Marks</li></a>
                <a class="tab-3" href="#tab-3"><li>View Student Marks</li></a>
            </ul>
        </nav></center>

    <center><section id="tab-1" hidden>
            <div>
                <table>
                    <tr>
                        <td><input type="text" name="fname" id="fname" placeholder="First Name"><?php set_value('fname') ?></td>
                        <td><input type="text" name="lname" id="lname" placeholder="Last Name"><?php set_value('lname') ?></td>
                    </tr>
                    <tr>
                        <td id='msg1'><?php echo form_error('fname'); ?></td>
                        <td id='msg2'><?php echo form_error('lname'); ?></td>
                    </tr>
                </table>
                <center><input type="button" id='addstudent' value="Add"></center>
                <div id='studentinfo'>
                    <center><table cellspacing="10">
                            <thead>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Action</th>
                            </thead>
                            <tbody><tr></tr></tbody>
                        </table></center>
                </div>
            </div>
        </section></center>

    <center><section id="tab-2" hidden>
            <p>Hello 2</p>
        </section></center>

    <center><section id="tab-3" hidden>
            <p>Hello 3</p>
        </section></center>
</body>
</html>