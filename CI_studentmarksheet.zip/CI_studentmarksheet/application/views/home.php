<?php
if(isset($this->session->userdata['user_info'])){
    $firstName = $this->session->userdata['user_info']['first_name'];
    $lastName = $this->session->userdata['user_info']['last_name'];
    $email = $this->session->userdata['user_info']['email'];
    $phoneNumber = $this->session->userdata['user_info']['phone_number'];
    $profilePicture = $this->session->userdata['user_info']['profile_picture'];
}
?>
<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
    </head>
    <body>
        <section class="profile">
            <table>
                <tr>
                    <td><h2><u>Welcome,</u></h2><h3><?php echo $firstName.' '.$lastName?></h3></td>
                    <td><img src="../../assets/uploads/<?php echo $profilePicture;?>" alt="profile" height="100" width="100"></td>
                </tr>
                <tr>
                    <td><p><u>Email</u></p><p><?php echo $email;?></p></td>
                </tr>
                <tr>
                    <td><p><u>Phone Number</u></p><p><?php echo $phoneNumber;?></p></td>
                </tr>
                <?php echo form_open('login/logout')?>
                <tr>
                    <td><input type="submit" value="Logout"></td>
                </tr>
                <?php echo form_close()?>
            </table>
        </section>
        <section class="result">
                <h1>Results</h1>
                <center><table class="resultTable">

                    </table></center>
        </section>
    </body>
</html>