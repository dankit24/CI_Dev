<html>
    <head>
        <title>Admin</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php FCPATH ?>/assets/js/script.js"></script>
    </head>
    <body>
    <center><section class="tabs">
            <nav class="menu">
                <ul>
                    <li class="tab-1"><a href="/admin">Student</a></li>
                    <li class="tab-2"><a href="/admin/marksheets">Mark Sheet</a></li>
                    <li class="tab-3"><a href="/admin/subjects">Subject</a></li>
                    <li><?php echo form_open('login/logout') ?><input type="submit" value="Logout"><?php echo form_close() ?></li>
                </ul>
            </nav>
        </section></center>