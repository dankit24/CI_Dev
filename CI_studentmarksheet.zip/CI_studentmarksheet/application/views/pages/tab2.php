    <section id="tab-2">
        <section id='markSheetSection'>
            <table cellpadding="5" cellspacing="10" align="center" id="viewtable">
                <tr style="margin-top: 5%;">
                    <th>Student Name</th>
                    <th>Total Marks</th>
                    <th>Marks Obtained</th>
                    <th>Average</th>
                    <th>Status</th>
                </tr>
                <tbody>
                </tbody>
            </table>
            <div id='links'>

            </div>
        </section>

        <section id='markInputSection'>
<?php echo form_open('manager/addMarks') ?>
            <table id="markInput">
                <tr>
                    <td><select id="studentList">
                        </select></td></tr>
                <tr><div id="displayError">Please Select a Student to add marks</div></tr>
                <tr>
                    <th hidden>Subject</th>
                    <th hidden>Practical Mark</th>
                    <th hidden>Viva Mark</th>
                    <th hidden>Total</th>
                <tbody id='markInputBody'></tbody>

                <tbody id="markSubmitBody" hidden>
                    <tr>
                        <th>Action</th><th>Total Marks</th><th>Average</th><th>Status</th>
                    </tr>
                    <tr>
                        <td><input type="submit" id="addTotal" value="Submit"></td>
                        <td><input type="text" id="mainTotal" readonly></td>
                        <td><input type="text" id="AvaraegMark" readonly></td>
                        <td><input type="text" id="status" readonly></td>
                    </tr>
                </tbody>
            </table>
<?php echo form_close(); ?>
        </section>
    </section>