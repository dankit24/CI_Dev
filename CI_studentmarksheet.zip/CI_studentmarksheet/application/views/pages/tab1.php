<section id="tab-1">
        <center><a href="<?php echo base_url('register') ?>"><button>Add New Student</button></a></center>

        <?php if (isset($results)) { ?>

            <table cellpadding="5" cellspacing="10" align="center">
                <?php echo form_open('manager'); ?>
                <tr>
                    <td colspan="4"><input type="search" name="search" id="search" placeholder="Student Name" style="width: 100%">
                        <input type="text" name="action" value="search" hidden></td>
                    <td colspan="1"><input type="submit" value="Search" style="width: 100%"></td>
                </tr>
                <?php echo form_close() ?>
                <tr style='margin-top: 5%;'>
                    <th>Profile Picture</th>
                    <th>Student Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($results as $data) { ?>
                    <tr>
                        <td><center><img src="../../assets/uploads/<?php echo $data->profile_picture ?>" alt="profile" width="50" height="50"></center></td>
                    <td><?php echo $data->first_name . ' ' . $data->last_name ?></td>
                    <td><?php echo $data->email ?></td>
                    <td><?php echo $data->phone_number ?></td>
                    <td><input type='button' value='edit' onclick="editStudent(<?php echo $data->user_id ?>)">
                        <input type='button' value='delete' onclick="deleteStudent(<?php echo $data->user_id ?>)"></td>
                    </tr>
                <?php } ?>
            </table>
            <?php if (isset($links)) { ?>
                <?php echo $links ?>
            <?php } ?>
        <?php } else { ?>
            <div>No student(s) found.</div>
            <?php } ?>
    </section><?php


