<section id="tab-3">
        <center><h1>Add Subjects</h1></center>

        <center><table><tr>
                    <td>Subject Name</td><td><input type="text" id="subject" name="subject"></td><td><input type="button" id="addsubject" value="ADD"></td>
                </tr></table></center>

        <center><table id="subjectList">
                <thead><th>Subject Name</th></thead>
                <tbody></tbody>
            </table></center>
    </section>