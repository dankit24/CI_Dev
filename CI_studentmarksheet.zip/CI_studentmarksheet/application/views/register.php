<html>
    <head>
        <title>Register</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php FCPATH ?>/assets/js/validation.js"></script>
        <?php
        $userId='';
        $firstName='';
        $lastName='';
        $email='';
        $phoneNumber='';
        $profilePicture='';
        if (isset($this->session->userdata['update_data'])) {
            $userId = $this->session->userdata['update_data']['user_id'];
            $firstName = $this->session->userdata['update_data']['first_name'];
            $lastName = $this->session->userdata['update_data']['last_name'];
            $email = $this->session->userdata['update_data']['email'];
            $phoneNumber = $this->session->userdata['update_data']['phone_number'];
            $profilePicture = $this->session->userdata['update_data']['profile_picture'];
            ?><script>
            $(document).ready(function () {
                $("#emailtr").remove();
                $("#confirmPasswordtr").remove();
            });
            </script>
            <?php
        }
        ?>
    </head>
    <body>
    <center><h1>Student Registration</h1></center>
    <?php
    if (isset($this->session->userdata['update_data'])) {
        echo form_open_multipart('register');
        echo '<input type="text" name="userId" value="' . $userId . '" hidden>';
        echo '<input type="text" name="action" value="saveStudent" hidden>';
    } else {
        echo form_open_multipart('register');
    }
    ?>
    <center><table>
            <tr>
                <td>First Name</td>
                <td><input type="text" id="firstName" name="firstName" value="<?php echo set_value('firstName'); ?><?php echo $firstName; ?>"><?php echo form_error('firstName'); ?></td>
            </tr>
            <tr>
                <td>Last Name</td><td><input type="text" id="lastName" name="lastName" value="<?php echo set_value('lastName'); ?><?php echo $lastName; ?>"><?php echo form_error('lastName'); ?></td>
            </tr>
            <tr id="emailtr">
                <td>Email</td><td><input type="text" id='email' name="email" value="<?php echo set_value('email'); ?><?php echo $email; ?>"><?php echo form_error('email'); ?></td>
            </tr>
            <tr>
                <td>Phone Number</td><td><input type="text" id='phoneNumber' name="phoneNumber" value="<?php echo set_value('phoneNumber'); ?><?php echo $phoneNumber; ?>"><?php echo form_error('phoneNumber'); ?></td>
            </tr>
            <tr>
                <td>profile</td><td><input type="file" name="profilePicture" value="<?php echo set_value('profilePicture'); ?><?php echo $profilePicture; ?>"></td>
            </tr>
            <tr hidden>
                <td>User Role</td><td><input type="text" name="userRole" value="2"></td>
            </tr>
            <tr>
                <td>Password</td><td><input type="password" id='password' name="password" value="<?php echo set_value('password'); ?>"><?php echo form_error('password'); ?></td>
            </tr>
            <tr id="confirmPasswordtr">
                <td>Confirm Password</td><td><input type="password" id='confirmPassword' name="confirmPassword" value="<?php echo set_value('confirmPassword'); ?>"><?php echo form_error('confirmPassword'); ?></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" id="registerSubmit" name="Submit"></td>
            </tr>
        </table></center>
    <?php echo form_close(); ?>
</body>
</html>