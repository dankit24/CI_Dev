<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Manager extends CI_Controller {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('pagination', 'form_validation', 'session'));
        $this->load->model('Manager_model');

        if (!$this->session->userdata('user_info')) {
            redirect('login');
        }
    }

    function index() {
        $action = $this->input->post('action');

        if ($action === 'search') {
            $search = $this->input->post('search');
// init params
            $params = array();
            $limit_per_page = 5;
            $start_index = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
            $total_records = $this->Manager_model->getTotal($search);
        } else {
// init params
            $params = array();
            $search = array();
            $limit_per_page = 5;
            $start_index = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
            $total_records = $this->Manager_model->getTotal($search);
        }
        if ($total_records > 0) {
// get current page records
            $params["results"] = $this->Manager_model->getStudentList($limit_per_page, $start_index, $search);

            $config['base_url'] = 'admin';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 2;

// custom paging configuration

            $config['reuse_query_string'] = TRUE;

            $config['full_tag_open'] = '<center><table class="pagination">';
            $config['full_tag_close'] = '</table></center>';

            $config['first_link'] = 'First';
            $config['first_tag_open'] = '<td>';
            $config['first_tag_close'] = '</td>';

            $config['last_link'] = 'Last';
            $config['last_tag_open'] = '<td>';
            $config['last_tag_close'] = '</td>';

            $config['next_link'] = 'Next';
            $config['next_tag_open'] = '<td>';
            $config['next_tag_close'] = '</td>';

            $config['prev_link'] = 'Prev';
            $config['prev_tag_open'] = '<td>';
            $config['prev_tag_close'] = '</td>';

            $config['cur_tag_open'] = '<td>';
            $config['cur_tag_close'] = '</td>';

            $config['num_tag_open'] = '<td>';
            $config['num_tag_close'] = '</td>';

            $this->pagination->initialize($config);

// build paging links
            $params["links"] = $this->pagination->create_links();
        }
        $this->load->view('template/header');
        $this->load->view('pages/tab1', $params);
        //$this->load->view('pages/footer');
    }

    function marksheets() {
        $this->load->view('template/header');
        $this->load->view('pages/tab2');
        //$this->load->view('pages/footer');
    }

    function subjects() {
        $this->load->view('template/header');
        $this->load->view('pages/tab3');
        //$this->load->view('pages/footer');
    }

    /**
     * operations add marks,add subjects
     */
    function addMarks() {
        $user_id = $this->input->post('user_id');
        $subject_id = $this->input->post('subject_id');
        $practical_mark = $this->input->post('practicalMark');
        $viva_mark = $this->input->post('vivaMark');
        $result = $this->Manager_model->addMarks($user_id, $subject_id, $practical_mark, $viva_mark);
        if ($result === TRUE) {
            redirect('admin/marksheets');
        }
    }

    function addSubject() {
        $subject = $this->input->post('subject');
        $result = $this->Manager_model->addSubject($subject);
        if ($result === TRUE) {
            echo TRUE;
        }
    }

    function editStudent() {
        $user_id = $this->input->get('id');
        $result = $this->Manager_model->editStudent($user_id);
        $this->session->set_userdata('update_data', $result);
    }

    function deleteStudent() {
        $user_id = $this->input->get('id');
        $result = $this->Manager_model->deleteStudent($user_id);
        echo TRUE;
        if ($result === 1) {
            echo TRUE;
        }
    }

    function loadSubject() {
        $result = $this->Manager_model->getSubject();
        if ($result !== FALSE) {
            echo $result;
        }
    }

    function loadStudent() {
        $result = $this->Manager_model->loadStudent();
        if ($result !== FALSE) {
            echo $result;
        }
    }

    function viewStudentMark() {
        $search = 'viewStudentMark';
        $start_index = '';
        $limit_per_page = '';
        $result = $this->Manager_model->getStudentList($limit_per_page, $start_index, $search);
        echo $result;
    }

}
