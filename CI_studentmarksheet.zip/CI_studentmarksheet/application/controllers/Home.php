<?php

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation'));
        $this->load->model('operations');
    }

    public function index() {
        $this->load->view('home');
    }

    public function add() {
        $action = $this->input->post('action');
        switch ($action) {
            case "addstudent":
                $data = array('firstname' => $this->input->post('firstname'),
                    'lastname' => $this->input->post('lastname'));
                $result = $this->operations->addstudent($data);
                if ($result == TRUE) {
                    echo TRUE;
                }
                break;
            case "addstudentmarks":
                $studentid = $this->input->post('studentid');
                $subject = $this->input->post('subject');
                $practicalmark = $this->input->post('pmarks');
                $vivamark = $this->input->post('vmarks');
                $result = $this->operations->addstudentmarks($studentid, $subject, $practicalmark, $vivamark);
                if ($result == TRUE) {
                    echo TRUE;
                }
                break;
        }
    }

    public function update() {
        $action = $this->input->post('action');
        switch ($action) {
            case "showstudent":
                $datalist = $this->operations->showstudent();
                echo $datalist;
                break;
            case "geteditinfo":
                $studentid = $this->input->post('studentid');
                $geteditdata = $this->operations->geteditinfo($studentid);
                echo $geteditdata;
                break;
            case "updatestudent":
                $data = array('firstname' => $this->input->post('firstname'),
                    'lastname' => $this->input->post('lastname'),
                    'studentid' => $this->input->post('studentid'));
                $result = $this->operations->updatestudent($data);
                if ($result == TRUE) {
                    echo TRUE;
                }
                break;
            case "loadstudent":
                $loadlist = $this->operations->loadstudent();
                echo $loadlist;
                break;
            case "viewstudentoverview":
                $viewoverview = $this->operations->viewstudentoverview();
                echo $viewoverview;
                break;
            case "viewstudentbrief":
                $studentid = $this->input->post('studentid');
                $viewbrief = $this->operations->viewstudentbrief($studentid);
                echo $viewbrief;
                break;
        }
    }

}
