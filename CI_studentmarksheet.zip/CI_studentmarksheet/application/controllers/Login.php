<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Login extends CI_Controller {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Login_Model');
        $this->load->database();
    }

    function index() {
        if (!$this->session->userdata('user_info')) {
            $this->form_validation->set_error_delimiters('<label class="error">', '</label>');
            $config = array(
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|valid_email',
                    'errors' => array('required' => '%s is Required!!!',
                        'valid_email' => '%s is not valid email!!!'),
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required|min_length[6]',
                    'errors' => array('required' => '%s is Required!!!',
                        'min_length' => '%s should be atleast 6 character long!!!'),
                ),
            );
            $this->form_validation->set_rules($config);
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('login');
            } else {
                $data = array(
                    'email' => $this->input->post('email'),
                    'password' => $this->input->post('password')
                );
                $result = $this->Login_Model->login($data);
                if ($result !== FALSE) {
                    $this->session->set_userdata('user_info', $result);
                    $this->redirect();
                } else {
                    $url = base_url('login');
                    header("Refresh: 0; url=$url");
                }
            }
        }
        else{
            $this->redirect();
        }
    }

    function redirect() {
        if ($this->session->userdata['user_info']['user_role'] === 'user') {
            $this->load->view('home');
        } else if ($this->session->userdata['user_info']['user_role'] === 'admin') {
            redirect(base_url('admin'));
        }
    }

    /**
     * unset and destroy session for logout
     */
    function logout() {
        if ($this->session->userdata('user_info')) {
            $this->session->unset_userdata('user_info');
            $this->session->sess_destroy();
            redirect('login');
        }
    }

}
