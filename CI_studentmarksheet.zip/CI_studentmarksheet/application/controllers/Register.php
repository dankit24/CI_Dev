<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Register extends CI_Controller {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Register_Model');
    }

    /**
     * validate input fields and give data to model to add into table 
     */
    public function index() {
        $this->form_validation->set_error_delimiters('<label class="error">', '</label>');
        if (isset($this->session->userdata['update_data'])) {
            $config = array(
                array(
                    'field' => 'firstName',
                    'label' => 'First Name',
                    'rules' => 'required|alpha',
                    'errors' => array('required' => '%s is Required!!!',
                        'alpha' => '%s should contain only alphabets!!!'),
                ),
                array(
                    'field' => 'lastName',
                    'label' => 'Last Name',
                    'rules' => 'required|alpha',
                    'errors' => array('required' => '%s is Required!!!',
                        'alpha' => '%s should contain only alphabets!!!'),
                ),
                array(
                    'field' => 'phoneNumber',
                    'label' => 'Phone Number',
                    'rules' => 'required|numeric|min_length[10]|max_length[10]',
                    'errors' => array('required' => '%s is Required!!!',
                        'numeric' => 'only numbers allowed!!!',
                        'max_length' => '%s is not correct!!!',
                        'min_length' => '%s is not correct!!!'),
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required|min_length[6]',
                    'errors' => array('required' => '%s is Required!!!',
                        'min_length' => '%s should be atleast 8 character long!!!'),
                ),
            );
        } else {
            $config = array(
                array(
                    'field' => 'firstName',
                    'label' => 'First Name',
                    'rules' => 'required|alpha',
                    'errors' => array('required' => '%s is Required!!!',
                        'alpha' => '%s should contain only alphabets!!!'),
                ),
                array(
                    'field' => 'lastName',
                    'label' => 'Last Name',
                    'rules' => 'required|alpha',
                    'errors' => array('required' => '%s is Required!!!',
                        'alpha' => '%s should contain only alphabets!!!'),
                ),
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|valid_email|is_unique[user.email ]',
                    'errors' => array('required' => '%s is Required!!!',
                        'valid_email' => '%s is not valid email!!!',
                        'is_unique' => '%s is already registerd!!!'),
                ),
                array(
                    'field' => 'phoneNumber',
                    'label' => 'Phone Number',
                    'rules' => 'required|numeric|min_length[10]|max_length[10]',
                    'errors' => array('required' => '%s is Required!!!',
                        'numeric' => 'only numbers allowed!!!',
                        'max_length' => '%s is not correct!!!',
                        'min_length' => '%s is not correct!!!'),
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required|min_length[6]',
                    'errors' => array('required' => '%s is Required!!!',
                        'min_length' => '%s should be atleast 6 character long!!!'),
                ),
                array(
                    'field' => 'confirmPassword',
                    'label' => 'Password Confirmation',
                    'rules' => 'required|min_length[6]|matches[password]',
                    'errors' => array('required' => '%s is Required!!!',
                        'min_length' => 'should be atleast 8 character long!!!',
                        'matches' => "Entered password doesnot match."),
                ),
            );
        }
        $this->form_validation->set_rules($config);
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('register');
        } else {

            $config['upload_path'] = FCPATH . '/assets/uploads';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 0;
            $config['max_width'] = 0;
            $config['max_height'] = 0;
            $config['encrypt_name'] = TRUE;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('profilePicture')) {
                $profile = $this->upload->data();

                $profilePicture = $profile['file_name'];
            } else {
                $profilePicture = 'default.png';
            }

            if ($this->input->post('action') === 'saveStudent') {
                $user_id = $this->input->post('userId');
                $password = $this->input->post('password');
                $data = array(
                    'first_name' => $this->input->post('firstName'),
                    'last_name' => $this->input->post('lastName'),
                    'phone_number' => $this->input->post('phoneNumber'),
                    'profile_picture' => $profilePicture,
                    'user_role' => $this->input->post('userRole')
                );
                $result = $this->Register_Model->update($data,$password,$user_id);
                if ($result === TRUE) {
                    $this->session->unset_userdata('update_data');
                    if (isset($this->session->userdata['user_info'])) {
                        redirect(base_url('admin'));
                    } else {
                        redirect(base_url('login'));
                    }
                } else {
                    
                }
            } else {
                $data = array(
                    'first_name' => $this->input->post('firstName'),
                    'last_name' => $this->input->post('lastName'),
                    'email' => $this->input->post('email'),
                    'phone_number' => $this->input->post('phoneNumber'),
                    'profile_picture' => $profilePicture,
                    'user_role' => $this->input->post('userRole'),
                    'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
                );
                $result = $this->Register_Model->register($data);
                if ($result === TRUE) {
                    if (isset($this->session->userdata['user_info'])) {
                        redirect(base_url('admin'));
                    } else {
                        redirect(base_url('login'));
                    }
                } else {
                    echo 'data not stored';
                }
            }
        }
    }

}
