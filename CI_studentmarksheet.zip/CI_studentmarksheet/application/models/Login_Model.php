<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Login_Model extends CI_Model {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * verify inout email and password and load data of user  into session
     * @param type $data
     * @return boolean
     */
    function login($data) {

        $this->db->select('user_id,password');
        $this->db->from('user');
        $this->db->where('email', $data['email']);
        $result = $this->db->get();
        $userData = $result->row_array();
        
        if (password_verify($data['password'], $userData['password'])) {
            $this->db->select('user_id,user_role,first_name,last_name,email,phone_number,profile_picture');
            $this->db->from('user');
            $this->db->where('user_id',$userData['user_id']);
            $result = $this->db->get();
            $userInfo = $result->row_array();
            return $userInfo;
        } else {
            return FALSE;
        }
    }

}
