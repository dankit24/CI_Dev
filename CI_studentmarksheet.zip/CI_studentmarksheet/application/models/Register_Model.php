<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Register_Model extends CI_Model {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * get all data of user and insert into table
     * @param type $data
     * @return boolean
     */
    function register($data) {
        $result = $this->db->insert('user', $data);
        if ($result === TRUE) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function update($data, $password, $user_id) {
        $this->db->select('password');
        $this->db->from('user');
        $this->db->where('user_id', $user_id);
        $result = $this->db->get();
        $result = $result->row_array();
        $hash_password = $result['password'];
        if (password_verify($password, $hash_password)) {
            $this->db->where('user_id', $user_id);
            $result = $this->db->update('user', $data);
            if ($result === TRUE) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
        else{
            return FALSE;
        }
    }
}