<?php

class operations extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function addstudent($data) {
        $this->db->insert('student', $data);
        return TRUE;
    }

    public function showstudent() {
        $result = $this->db->get('student');
        $datalist = json_encode($result->result_array());
        return $datalist;
    }

    public function geteditinfo($studentid) {
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('studentid=', $studentid);
        $result = $this->db->get();
        $datalist = json_encode($result->result_array());
        return $datalist;
    }

    public function updatestudent($data) {
        $sql = "UPDATE student SET firstname='$data[firstname]',lastname='$data[lastname]' WHERE studentid=$data[studentid]";
        $result = $this->db->query($sql);
        return $result;
    }
    
    public function addstudentmarks($studentid,$subject,$practicalmark,$vivamark){
    for($i = 0;$i<count($subject);$i++){
        $sql = "INSERT INTO mark (studentid,subject,practicalmark,vivamark) VALUES('$studentid','$subject[$i]','$practicalmark[$i]','$vivamark[$i]')";
        $result = $this->db->query($sql);
    }
        return  $result;
    }
    public function loadstudent(){
        $sql = 'select studentid, CONCAT(firstname, " ", lastname) AS fullname from student WHERE studentid NOT IN(select studentid from mark)';
        $result = $this->db->query($sql);
        $loadlist = json_encode($result->result_array());
        return $loadlist;
    }
    public function viewstudentoverview(){
        $sql = 'select m.studentid,concat(s.firstname," ",s.lastname) as fullname,SUM(practicalmark+vivamark) as total,AVG(practicalmark+vivamark) as avarage from mark m ,student s where s.studentid = m.studentid group by m.studentid ';
        $result = $this->db->query($sql);
        $viewoverview = json_encode($result->result_array());
        return $viewoverview;
    }
    public function viewstudentbrief($studentid){
        $sql ='select s.firstname, s.lastname, GROUP_CONCAT(m.subject) as subject, GROUP_CONCAT(m.practicalmark) as practicalmark, '
                . 'GROUP_CONCAT(m.vivamark) as vivamark, SUM(m.practicalmark+m.vivamark) AS total, AVG(m.practicalmark+m.vivamark) AS avarage '
                . 'from student s,mark m where m.studentid = s.studentid and m.studentid = '.$studentid.' group by m.studentid';
        $result = $this->db->query($sql);
        $viewbrief = json_encode($result->result_array());
        return $viewbrief;
    }
}
