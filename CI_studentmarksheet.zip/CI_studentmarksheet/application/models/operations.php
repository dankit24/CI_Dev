<?php

class operations extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function addstudent($data) {
        $this->db->insert('student', $data);
        return TRUE;
    }

    public function showstudent() {
        $result = $this->db->get('student');
        $datalist = json_encode($result->result_array());
        return $datalist;
    }

    public function geteditinfo($studentid) {
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('studentid=', $studentid);
        $result = $this->db->get();
        $datalist = json_encode($result->result_array());
        return $datalist;
    }

    public function updatestudent($data) {
        $sql = "UPDATE student SET firstname='$data[firstname]',lastname='$data[lastname]' WHERE studentid=$data[studentid]";
        $result = $this->db->query($sql);
        return $result;
    }

}
