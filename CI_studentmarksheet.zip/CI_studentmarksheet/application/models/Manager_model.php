<?php

/*
  Created on : Apr 6, 2018, 5:14:43 PM
  Author     : php
 */

class Manager_model extends CI_Model {

    /**
     * load helpers and libraries
     */
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * get starting index and limit per page and return records for pagination
     * @param type $limit
     * @param type $start
     * @return boolean
     */
    function getStudentList($limit, $start, $search) {
        if ($search === 'viewStudentMark') {
            $sql = "select distinct(concat(u.first_name,' ',u.last_name)) as full_name,sum(m.practical_mark+m.viva_mark) as total,"
                    . "avg(m.practical_mark+m.viva_mark) as average,count(subject_id) as count from mark m , user u  where u.user_role = 'user' "
                    . "and u.user_id = m.user_id group by m.user_id";
            $result = $this->db->query($sql);
            if ($result->num_rows() > 0) {
                $result = json_encode($result->result_array());
            }
            return $result;
        }
        if (empty($search)) {
            $this->db->limit($limit, $start);
            $query = $this->db->get_where("user", array('user_role' => 'user'));

            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $data[] = $row;
                }

                return $data;
            }
        } else {
            $sql = "select * from user where user_role = 'user' and concat(first_name,' ',last_name) like '%$search%'";
            $result = $this->db->query($sql);
            if ($result->num_rows() > 0) {
                foreach ($result->result() as $row) {
                    $data[] = $row;
                }
                return $data;
            }
            else{
                return FALSE;
            }
        }
        return FALSE;
    }

    /**
     * return total number of records without admin
     * @return type
     */
    function getTotal($search) {
        if (empty($search)) {
            return ($this->db->count_all('user') - 1);
        } else {
            $sql = "select count(*) as count from user where user_role = 'user' and concat(first_name,' ',last_name) like '%$search%'";
            $result = $this->db->query($sql);
            $result = $result->row_array();
            return $result['count'];
        }
    }

    /**
     * get user_id and return all fields of that id for update form
     * @param type $user_id
     * @return type
     */
    function editStudent($user_id) {
        $this->db->select('user_id,first_name,last_name,email,phone_number,profile_picture,');
        $this->db->from('user');
        $this->db->where('user_id', $user_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    /**
     * get user_id and delete records from user and mark table
     * @param type $user_id
     * @return type
     */
    function deleteStudent($user_id) {
        $this->db->where('user_id', $user_id);
        $result = $this->db->delete('user');
        return $result;
    }

    /**
     * function to add subjects into subject table
     * @param type $subject
     * @return type
     */
    function addSubject($subject) {
        $result = $this->db->insert('subject', array('subject' => $subject));
        return $result;
    }

    /**
     * function to retrive subjects from table
     * @return type
     */
    function getSubject() {
        $this->db->select('*');
        $this->db->from('subject');
        $result = $this->db->get();
        return json_encode($result->result_array());
    }

    /**
     * load students into select list form user table which records are not present in mark table
     * @return type
     */
    function loadStudent() {
        $sql = 'select  user_id,CONCAT(first_name," ",last_name) as full_name from user where user_role = "user" and user_id not in(select user_id from mark)';
        $result = $this->db->query($sql);
        return json_encode($result->result_array());
    }

    /**
     * add all fields into mark table from user input
     * @param type $user_id
     * @param type $subject_id
     * @param type $practical_mark
     * @param type $viva_mark
     * @return type
     */
    function addMarks($user_id, $subject_id, $practical_mark, $viva_mark) {
        for ($i = 0; $i < count($subject_id); $i++) {
            $user = $user_id;
            $subject = trim($subject_id[$i]);
            $practical = trim($practical_mark[$i]);
            $viva = trim($viva_mark[$i]);
            if ($practical !== '' && $viva !== '') {
                $sql = "INSERT INTO mark (user_id,subject_id,practical_mark,viva_mark) VALUES($user,$subject,$practical,$viva)";
                $result = $this->db->query($sql);
            }
        }
        return $result;
    }

}
