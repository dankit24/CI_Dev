/* 
 Created on : Apr 6, 2018, 5:14:43 PM
 Author     : php
 */
$(document).ready(function () {
    $("#firstName").on('blur', function () {

        if ($("#firstName").val() === '') {
            $("#firstName").attr('placeholder', 'enter firstname');
        }
    });
    $("#lastName").on('blur', function () {
        if ($("#lastName").val() === '') {
            $("#lastName").attr('placeholder', 'enter lastname');
        }
    });
    $("#email").on('blur', function () {
        if ($("#email").val() === '') {
            $("#email").attr('placeholder', 'enter email');
        }
    });
    $("#phoneNumber").on('blur', function () {
        if ($("#phoneNumber").val() === '') {
            $("#phoneNumber").attr('placeholder', 'enter phone number');
        }
    });
    $("#password").on('blur', function () {
        if ($("#password").val() === '') {
            $("#password").attr('placeholder', 'enter password');
        }
    });
    $("#confirmPassword").on('blur', function () {
        if ($("#confirmPassword").val() === '') {
            $("#confirmPassword").attr('placeholder', 'confirm password');
        } else if ($("#confirmPassword").val() !== $("#password").val()) {
            alert('password do not match');
        }
    });
});

$(document).ready(function () {
    $("#registerSubmit").click(function (e) {
        e.preventDefault();

        if ($('#firstName').val() === '' || $('#lastName').val() === '' || $('#email').val() === '' || $('#phoneNumber').val() === '' || $('#password').val() === '' || $('#confirmPassword').val() === '') {
            alert('all field required');
        } else {
            $("#registerSubmit").unbind('keyup').keyup().unbind('click').click();
        }
    });
});

$(document).ready(function () {
    $("#loginSubmit").click(function (e) {
        e.preventDefault();

        if ($('#email').val() === '' || $('#password').val() === '') {
            alert('all field required');
        } else {
            $("#loginSubmit").unbind('keyup').keyup().unbind('click').click();
        }
    });
});