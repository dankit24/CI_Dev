/* 
 Created on : Apr 6, 2018, 5:14:43 PM
 Author     : php
 */

/**
 * tab navigation
 */
$(document).ready(function () {
    $('.tab-1').on('click', function () {

        $('#tab-1').show();
        $('#tab-2').hide();
        $('#tab-3').hide();
    });
    $('.tab-2').on('click', function () {
        $('#tab-2').toggle();
        $('#tab-3').hide();
        $('#tab-1').hide();
    });
    $('.tab-3').on('click', function () {
        $('#tab-3').toggle();
        $('#tab-1').hide();
        $('#tab-2').hide();
    });

    /**
     * add subject to database
     */
    $('#addsubject').on('click', function () {
        $.ajax({
            url: location.origin+"/admin/addsubject",
            type: 'POST',
            data: 'subject=' + $("#subject").val(),
            success: function (data) {
                alert('subject added.');
            }
        });
    });

    /**
     * load student list into marksheet
     */
    $.ajax({
        url: location.origin+"/admin/loadStudent",
        type: 'POST',
        success: function (data) {
            var data = JSON.parse(data);
            if(data.length !== 0){
            $('#studentList').empty().append('<option disabled selected hidden>Student</option>');
            $.each(data, function () {
                $('#studentList').append('<option value = "' + this.user_id + '">' + this.full_name + '</option>');
            });
        }
        else{
            $("#studentList").hide();
            $("#displayError").empty().append('No Student(s) to Generate Marksheet.');
        }
    }
    });
    /**
     * 
     */

        $.ajax({
            url: location.origin+"/admin/viewStudentMark",
            type: 'POST',
            success: function (data) {
                var results = JSON.parse(data);
                 console.log(results);
                if (results !== undefined) {
                    var len = results.length;
                    
                    $.each(results ,function (){
                        var status = statusClass(this.average);
                        var markup = '<tr>\n\
                                        <td>' + this.full_name + '</td>\n\
                                        <td>' + (this.count * 100) + '</td>\n\
                                        <td>' + this.total + '</td>\n\
                                        <td>' + this.average + '</td>\n\
                                        <td>' + status + '</td></tr>';
                        $("#viewtable").append(markup);
                    });
                }
                else{
                   $("#viewtable").hide();
                   var markup = '<div>No result(s) found.</div>';
                    $("#markSheetSection").append(markup);
                    
                }
            }
        });

});

/**
 * load marksheet dynamic content
 */
$(document).ready(function () {
    $.ajax({
        url: location.origin+"/admin/loadSubject",
        type: 'POST',
        success: function (data) {
            if (data !== null) {
                data = JSON.parse(data);
                var i;
                var user_id;
                var len = data.length;
                $('#subjectList tbody').empty();
                $.each(data, function () {
                    var markup = '<tr><td>' + this.subject + '</td><td><input type="button" value="Delete" onclick="deleteSubject('+this.subject_id+')"></td></tr>';
                    $('#subjectList tbody').append(markup);
                });
                $("#studentList").on('change', function () {
                    if ($("#studentList").val() !== undefined) {
                        i = 0;
                        $("#totalCount").show();
                        $("#markInput th").show();
                        $("#markSubmitBody").show();
                        user_id = $("#studentList").val();
                        $('#markInputBody').empty();
                        $("#displayError").remove();
                        $.each(data, function () {
                            var markup = "<tr><td>" + this.subject + "<input type='text' id='subject_id" + i + "' name='subject_id[]' value=" + this.subject_id + " hidden>\n\
                            <input type='text' id='user_id' name='user_id' value=" + user_id + " hidden></td>\n\
                            <td><input type='text' id='practicalMark" + i + "' name='practicalMark[]'></td>\n\
                            <td><input type='text' id='vivaMark" + i + "' name='vivaMark[]'></td>\n\
                            <td><input type='text' id='total" + i + "' readonly></td></tr>";
                            $('#markInputBody').append(markup);
                            i++;
                        });
                    } else {
                        $("#displayError").show();
                    }
                });
                for (var k = 0; k < len; k++) {
                    countTotal(k);
                }
            }
        }
    });
});

/**
 * send edit request to load update page by id
 * @param {type} id
 * @returns {undefined}
 */
function editStudent(id) {
    $.ajax({
        url: location.origin+"/admin/editStudent",
        type: 'GET',
        data: 'id=' + parseInt(id),
        success: function (data) {
            location.replace((location.origin+'/register'));
        }
    });
}

/**
 * send a AJAX request to delete student by id
 * @param {type} id
 * @returns {undefined}
 */
function deleteStudent(id) {
    $.ajax({
        url: location.origin+"/admin/deleteStudent",
        type: 'GET',
        data: 'id=' + parseInt(id),
        success: function (data) {
            if (data === '1') {
                location.replace(location.origin+'/admin');
            }
        }
    });
}

function deleteSubject(id){
    alert(id);
}

/**
 * calculate total marks from practical and viva marks
 * @param {type} k
 * @returns {undefined}
 */
function countTotal(k) {
    $('#markInput').on('blur', '#practicalMark' + k, function () {
        if ($("#practicalMark" + k).val() <= '70') {
            $('#total' + k).val(parseInt($('#practicalMark' + k).val()));
            calculateTotal(k);
        } else {
            alert('practical mark should be out of 70');
            $('input[id^=practicalMark' + k + ']').val('');
            $('input[id^=practicalMark' + k + ']').focus();
        }
    });
    $('#markInput').on('blur', '#vivaMark' + k, function () {
        if ($("#vivaMark" + k).val() <= '30') {
            $('#total' + k).val(parseInt($('#practicalMark' + k).val()) + parseInt($('#vivaMark' + k).val()));
            calculateTotal(k);
        } else {
            alert('viva mark should be out of 30');
            $('input[id^=vivaMark' + k + ']').val('');
            $('input[id^=vivaMark' + k + ']').focus();
        }
    });
}

/**
 * calculate and update main total,avarage,status
 * @param {type} k
 * @returns {undefined}
 */
function calculateTotal(k) {
    var total = [];
    for (var i = 0; i <= k; i++) {
        total.push($("input[id^='total" + i + "']").val());
    }
    total = jQuery.grep(total, function (n) {
        return (n);
    });
    var mainTotal = 0;
    var avarage = 0;
    var status = '';
    for (var i = 0; i < total.length; i++) {
        mainTotal += parseInt(total[i]);
    }
    avarage = parseInt(mainTotal) / parseInt(total.length);
    status = statusClass(avarage);
    $("#mainTotal").val(mainTotal);
    $("#AvaraegMark").val(avarage);
    $("#status").val(status);
}
function statusClass(average) {
    if (average <= 50) {
        return status = 'FAIL';
    } else if (average <= 60) {
       return status = 'SECOND CLASS';
    } else if (average <= 70) {
       return status = 'FIRST CLASS';
    } else if (average >= 70) {
       return status = 'DISTINCTION';
    }
}