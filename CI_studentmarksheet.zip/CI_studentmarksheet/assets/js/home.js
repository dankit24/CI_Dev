/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
   $(".tab-1").on('click',function(){
      $("#tab-1").toggle();
      $("#tab-2").hide();
      $("#tab-3").hide();
   });
   $(".tab-2").on('click',function(){
      $("#tab-2").toggle();
      $("#tab-3").hide();
      $("#tab-1").hide();
   });
   $(".tab-3").on('click',function(){
      $("#tab-3").toggle();
      $("#tab-1").hide();
      $("#tab-2").hide();
   });
});