$(document).ready(function () {
    $(".tab-1").on('click', function () {
        $("#tab-1").toggle();
        $("#tab-2").hide();
        $("#tab-3").hide();
    });
    $(".tab-2").on('click', function () {
        $("#tab-2").toggle();
        $("#tab-3").hide();
        $("#tab-1").hide();
    });
    $(".tab-3").on('click', function () {
        $("#tab-3").toggle();
        $("#tab-1").hide();
        $("#tab-2").hide();
    });

    showstudent();

    $("#fname").on("blur", function () {
        if ($("#fname").val() === "" || $("#fname").val() === null) {
            $("#fname").attr('placeholder', "First Name Required").css({'font-size': 'medium'});
        }
    });
    $("#lname").on("blur", function () {
        if ($("#lname").val() === "" || $("#lname").val() === null) {
            $("#lname").attr('placeholder', "Last Name Required").css({'font-size': 'medium'});
        }
    });

    $("#addstudent").on('click', function () {
        if ($("#fname").val() === "" || $("#fname").val() === null || $("#lname").val() === "" || $("#lname").val() === null) {
            alert("all fields required");
        } else {

            $.ajax({
                type: 'POST',
                url: "home/add",
                data: "firstname=" + $("#fname").val() + "&lastname=" + $("#lname").val() + "&action=addstudent",
                success: function (data) {
                    if (data === '1') {
                        alert('Student Added.');
                        $("#fname").val('');
                        $("#lname").val('');
                        showstudent();
                    }
                }
            });
        }
    });
});

function showstudent() {
    $.ajax({
        type: 'POST',
        url: "home/update",
        data: "action=showstudent",
        success: function (data) {
            var list = JSON.parse(data);
            $("#studentinfo table tbody").empty();
            $.each(list, function () {
                var markup = "<tr><td>" + this.firstname + "</td>\n\
                            <td>" + this.lastname + "</td>\n\
                            <td><input type='button' value='Edit' onclick='editstudent(" + this.studentid + ")'></td></tr>";
                $("#studentinfo table tbody").append(markup);
            });
        }
    });
}


function editstudent(id) {
    $.ajax({
        url: "home/update",
        type: 'POST',
        data: "studentid=" + id + "&action=geteditinfo",
        success: function (data) {
            var list = JSON.parse(data);
            $.each(list, function () {
                var markup = "<td><input class='edit' type='text' name='ufname' id='ufname' value=" + this.firstname + "></td>\n\
                            <td><input class='edit' type='text' name='ulname' id='ulname' value=" + this.lastname + "></td>\n\
                            <td><input type='button' value='Save' onclick='savestudent(" + this.studentid + ")'></td>";
                $("#studentinfo table tbody tr").eq(id - 1).after().html(markup);
            });
        }
    });
}

function savestudent(id) {
    $.ajax({
        url: "home/update",
        type: 'POST',
        data: "firstname=" + $("#ufname").val() + "&lastname=" + $("#ulname").val() + "&studentid=" + id + "&action=updatestudent",
        success: function (data) {
            if (data === '1') {
                alert('Student Info Updated.');
                showstudent();
            }
        }
    });
}
$(document).ready(function () {
    $("#sub1").on('change', function () {
        if ($("#sub1").is(':checked')) {
            $("#prac1").prop('disabled', false).css({"background":"black"});
            $("#viva1").prop('disabled', false).css({"background":"black"});
        } else {
            $("#prac1").prop('disabled', true).css({"background":"gray"});
            $("#viva1").prop('disabled', true).css({"background":"gray"});
        }
    });
    $("#sub2").on('change', function () {
        if ($("#sub2").is(':checked')) {
            $("#prac2").prop('disabled', false).css({"background":"black"});
            $("#viva2").prop('disabled', false).css({"background":"black"});
        } else {
            $("#prac2").prop('disabled', true).css({"background":"gray"});
            $("#viva2").prop('disabled', true).css({"background":"gray"});
        }
    });
    $("#sub3").on('change', function () {
        if ($("#sub3").is(':checked')) {
            $("#prac3").prop('disabled', false).css({"background":"black"});
            $("#viva3").prop('disabled', false).css({"background":"black"});
        } else {
            $("#prac3").prop('disabled', true).css({"background":"gray"});
            $("#viva3").prop('disabled', true).css({"background":"gray"});
        }
    });
    $("#sub4").on('change', function () {
        if ($("#sub4").is(':checked')) {
            $("#prac4").prop('disabled', false).css({"background":"black"});
            $("#viva4").prop('disabled', false).css({"background":"black"});
        } else {
            $("#prac4").prop('disabled', true).css({"background":"gray"});
            $("#viva4").prop('disabled', true).css({"background":"gray"});
        }
    });
});
$(document).ready(function () {
    $("#addmarks").on('click', function () {
        if ($("#sub1").is(':checked')) {
            alert($("#prac1").val());
            alert($("#viva1").val());
        }
        if ($("#sub2").is(':checked')) {
            alert($("#prac2").val());
            alert($("#viva2").val());
        }
        if ($("#sub3").is(':checked')) {
            alert($("#prac3").val());
            alert($("#viva3").val());
        }
        if ($("#sub4").is(':checked')) {
            alert($("#prac4").val());
            alert($("#viva4").val());
        }
    });
});
