$(document).ready(function () {
    /**
     * tab navigation
     */
    $(".tab-1").on('click', function () {
        $("#tab-1").toggle();
        $("#tab-2").hide();
        $("#tab-3").hide();
    });
    $(".tab-2").on('click', function () {
        $("#tab-2").toggle();
        $("#tab-3").hide();
        $("#tab-1").hide();
    });
    $(".tab-3").on('click', function () {
        $("#tab-3").toggle();
        $("#tab-1").hide();
        $("#tab-2").hide();
    });
    showstudent();
    loadstudent();
    /**
     * name input form validation
     */
    $("#fname").on("blur", function () {
        if ($("#fname").val() === "" || $("#fname").val() === null) {
            $("#fname").attr('placeholder', "First Name Required").css({'font-size': 'medium'});
        }
    });
    $("#lname").on("blur", function () {
        if ($("#lname").val() === "" || $("#lname").val() === null) {
            $("#lname").attr('placeholder', "Last Name Required").css({'font-size': 'medium'});
        }
    });
    /**
     * add student into database
     */
    $("#addstudent").on('click', function () {
        if ($("#fname").val() === "" || $("#fname").val() === null || $("#lname").val() === "" || $("#lname").val() === null) {
            alert("all fields required");
        } else {
            $.ajax({
                type: 'POST',
                url: "home/add",
                data: "firstname=" + $("#fname").val() + "&lastname=" + $("#lname").val() + "&action=addstudent",
                success: function (data) {
                    if (data === '1') {
                        alert('Student Added.');
                        $("#fname").val('');
                        $("#lname").val('');
                        showstudent();
                        loadstudent();
                    }
                }
            });
        }
    });
});
function showstudent() {
    $.ajax({
        type: 'POST',
        url: "home/update",
        data: "action=showstudent",
        success: function (data) {
            var list = JSON.parse(data);
            $("#studentinfo table tbody").empty();
            $.each(list, function () {
                var markup = "<tr><td>" + this.firstname + "</td>\n\
                            <td>" + this.lastname + "</td>\n\
                            <td><input type='button' value='Edit' onclick='editstudent(" + this.studentid + ")'></td></tr>";
                $("#studentinfo table tbody").append(markup);
            });
        }
    });
}
function editstudent(id) {
    $.ajax({
        url: "home/update",
        type: 'POST',
        data: "studentid=" + id + "&action=geteditinfo",
        success: function (data) {
            var list = JSON.parse(data);
            $.each(list, function () {
                var markup = "<td><input class='edit' type='text' name='ufname' id='ufname' value=" + this.firstname + "></td>\n\
                            <td><input class='edit' type='text' name='ulname' id='ulname' value=" + this.lastname + "></td>\n\
                            <td><input type='button' value='Save' onclick='savestudent(" + this.studentid + ")'></td>";
                $("#studentinfo table tbody tr").eq(id - 1).after().html(markup);
            });
        }
    });
}
function savestudent(id) {
    $.ajax({
        url: "home/update",
        type: 'POST',
        data: "firstname=" + $("#ufname").val() + "&lastname=" + $("#ulname").val() + "&studentid=" + id + "&action=updatestudent",
        success: function (data) {
            if (data === '1') {
                alert('Student Info Updated.');
                showstudent();
                loadstudent();
            }
        }
    });
}
/**
 * marks input form validation
 */
$(document).ready(function () {
    $("#sub1").on('change', function () {
        if ($("#sub1").is(':checked')) {
            $("#prac1").prop('disabled', false).css({"background": "black"});
            $("#viva1").prop('disabled', false).css({"background": "black"});
        } else {
            $("#prac1").val("").prop('disabled', true).css({"background": "gray"});
            $("#viva1").val("").prop('disabled', true).css({"background": "gray"});
        }
    });
    $("#sub2").on('change', function () {
        if ($("#sub2").is(':checked')) {
            $("#prac2").prop('disabled', false).css({"background": "black"});
            $("#viva2").prop('disabled', false).css({"background": "black"});
        } else {
            $("#prac2").val("").prop('disabled', true).css({"background": "gray"});
            $("#viva2").val("").prop('disabled', true).css({"background": "gray"});
        }
    });
    $("#sub3").on('change', function () {
        if ($("#sub3").is(':checked')) {
            $("#prac3").prop('disabled', false).css({"background": "black"});
            $("#viva3").prop('disabled', false).css({"background": "black"});
        } else {
            $("#prac3").val("").prop('disabled', true).css({"background": "gray"});
            $("#viva3").val("").prop('disabled', true).css({"background": "gray"});
        }
    });
    $("#sub4").on('change', function () {
        if ($("#sub4").is(':checked')) {
            $("#prac4").prop('disabled', false).css({"background": "black"});
            $("#viva4").prop('disabled', false).css({"background": "black"});
        } else {
            $("#prac4").val("").prop('disabled', true).css({"background": "gray"});
            $("#viva4").val("").prop('disabled', true).css({"background": "gray"});
        }
    });
});
function validateinput(status) {
    switch (status) {
        case 'studentname':
            if ($("#studentname").val() === "" || $("#studentname").val() === null) {
                alert("Select Student");
                return false;
            } else {
                return true;
            }
            break;
        case 'allsubject':
            if ($("#sub1").is(':not(:checked)') && $("#sub2").is(':not(:checked)') && $("#sub3").is(':not(:checked)') && $("#sub4").is(':not(:checked)')) {
                alert("please select atleast one subject");
                return false;
            } else {
                if ($("#sub1").is(':checked')) {
                    if ($("#prac1").val() === "" || $("#prac1").val() === null || $("#viva1").val() === "" || $("#viva1").val() === null) {
                        alert("please enter practical and viva marks");
                        return false;
                    }
                }
                if ($("#sub2").is(':checked')) {
                    if ($("#prac2").val() === "" || $("#prac2").val() === null || $("#viva2").val() === "" || $("#viva2").val() === null) {
                        alert("please enter practical and viva marks");
                        return false;
                    }
                }
                if ($("#sub3").is(':checked')) {
                    if ($("#prac3").val() === "" || $("#prac3").val() === null || $("#viva3").val() === "" || $("#viva3").val() === null) {
                        alert("please enter practical and viva marks");
                        return false;
                    }
                }
                if ($("#sub4").is(':checked')) {
                    if ($("#prac4").val() === "" || $("#prac4").val() === null || $("#viva4").val() === "" || $("#viva4").val() === null) {
                        alert("please enter practical and viva marks");
                        return false;
                    }
                }
                return true;
            }
    }
}
/**
 * student marks table generation and total marks calculation
 */
$(document).ready(function () {
    $("#addmarks").on('click', function () {
        var status = ['studentname', 'allsubject'];
        var inputs = [];
        var stuid;
        var stuname;
        var subject = [];
        var pmarks = [];
        var vmarks = [];
        var temp = validateinput(status[0]);
        inputs.push(temp);
        if (inputs[0] === true) {
            var temp = validateinput(status[1]);
            inputs.push(temp);
            if (inputs[1] === true) {
                stuid = $("#studentname").val();
                stuname = $("#studentname option:selected").text();
                if ($("#sub1").is(':checked')) {
                    subject.push($("#sub1").val());
                    pmarks.push($("#prac1").val());
                    vmarks.push($("#viva1").val());
                }
                if ($("#sub2").is(':checked')) {
                    subject.push($("#sub2").val());
                    pmarks.push($("#prac2").val());
                    vmarks.push($("#viva2").val());
                }
                if ($("#sub3").is(':checked')) {
                    subject.push($("#sub3").val());
                    pmarks.push($("#prac3").val());
                    vmarks.push($("#viva3").val());
                }
                if ($("#sub4").is(':checked')) {
                    subject.push($("#sub4").val());
                    pmarks.push($("#prac4").val());
                    vmarks.push($("#viva4").val());
                }
                var total = [];
                var markup = [];
                for (var i = 0; i < subject.length; i++) {
                    total.push(parseInt(pmarks[i]) + parseInt(vmarks[i]));
                    markup.push("<tr><td>" + stuname + "<input type='text' name='studentid' value=" + stuid + " hidden></td>\n\
                                <td>" + subject[i] + "<input type='text' name='subject[]' value=" + subject[i] + " hidden></td>\n\
                                <td>" + pmarks[i] + "<input type='text' name='pmarks[]' value=" + pmarks[i] + " hidden></td>\n\
                                <td>" + vmarks[i] + "<input type='text' name='vmarks[]' value=" + vmarks[i] + " hidden></td>\n\
                                <td>" + total[i] + "</td></tr>");
                }
                $("#marksoverview tbody").empty().append(markup);
                var totalmarks = 0;
                for (var i = 0; i < total.length; i++) {
                    totalmarks += total[i];
                }
                $("#total").val(totalmarks);
                var avaragemarks = totalmarks / total.length;
                $("#avarage").val(avaragemarks);
            }
        }
    });
});
/**
 * marks input updatindg
 */
$(document).ready(function () {
    $("#studentname").on('change', function () {
        $("#marksinput input:checkbox").prop("checked", false);
        $("#marksinput input:text").val("").prop('disabled', true).css({"background": "gray"});
        $("#marksoverview tbody").empty();
    });
});
function loadstudent() {
    $.ajax({
        url: 'home/update',
        type: 'POST',
        data: 'action=loadstudent',
        success: function (data) {
            var list = JSON.parse(data);
            console.log(list[0].fullname);
            var markup = "<option selected hidden disabled value=''>Student Name</option>";
            $("#studentname").empty().append(markup);
            $.each(list, function () {
                markup = "<option value=" + this.studentid + ">" + this.fullname + "</option>";
                $("#studentname").append(markup);
            });
        }
    });
}

$(document).ready(function (){
   $.ajax({
        url: "home/update",
        type: 'POST',
        data: 'action=viewstudentoverview',
        success: function (data) {
            var overview = JSON.parse(data);
            var markup;
            $.each(overview,function (){
               markup = "<tr><td>"+this.fullname+"</td>\n\
                        <td>"+this.total+"</td>\n\
                        <td>"+this.avarage+"</td>\n\
                        <td><input type='button' value='View' onclick='viewstudent("+this.studentid+")'></td></tr>";
                $("#viewstudentoverview tbody").append(markup);
            });
            
        }
   });
});

function viewstudent(id){
    var markup;
    var sub = [];
    var pmark = [];
    var vmark = [];
    $.ajax({
        url: "home/update",
        type: 'POST',
        data: 'studentid='+id+'&action=viewstudentbrief',
        success: function (data) {
            var brief = JSON.parse(data);
            $.each(brief,function (){
               markup = "<td colspan='2'>"+this.firstname+"</td><td colspan='2'>"+this.lastname+"</td>" ;
               $("#first").empty().append(markup);
                
                pmark.push(this.practicalmark);
                vmark.push(this.vivamark);
                sub.push(this.subject);
            });
            alert(sub.length);
            for(var i=0;i<sub.length;i++){
                alert(sub[1]);
                markup = "<tr><td>"+sub[i]+"</td><td>"+pmark[i]+"</td><td>"+vmark[i]+"</td><td>status</td></tr>";
                $("#second").empty().append(markup);
            }
                  
        }
    });
}