package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class clientCompanyEmployeePage {
    WebDriver driver;
    public clientCompanyEmployeePage(WebDriver driver){this.driver=driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a") WebElement customerAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[4]/a") WebElement clientEmployeeSubTab;
    @FindBy(xpath = "") WebElement element;

    public void addNewClientEmployee(JSONObject data){

        this.customerAccountSetupTab.click();
        this.clientEmployeeSubTab.click();
        this.element.sendKeys(data.get("element").toString());
    }
}
