package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class supplierCompanySubPage {
    WebDriver driver;
    public supplierCompanySubPage(WebDriver driver){this.driver=driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a") WebElement supplierAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[2]/a") WebElement supplierSubsidiarySubTab;
    @FindBy(xpath = "") WebElement companySelect;
    @FindBy(xpath = "") WebElement companySelected;
    @FindBy(xpath = "") WebElement subsidiaryTaxID;
    @FindBy(xpath = "") WebElement subsidiaryName;
    @FindBy(xpath = "") WebElement subsidiaryTypeSelect;
    @FindBy(xpath = "") WebElement subsidiaryTypeSelected;
    @FindBy(xpath = "") WebElement notes;
    @FindBy(xpath = "") WebElement email;
    @FindBy(xpath = "") WebElement socialMediaID;
    @FindBy(xpath = "") WebElement website;
    @FindBy(xpath = "") WebElement mAddressLine1;
    @FindBy(xpath = "") WebElement mAddressLine2;
    @FindBy(xpath = "") WebElement mAddressLine3;
    @FindBy(xpath = "") WebElement mCity;
    @FindBy(xpath = "") WebElement mState;
    @FindBy(xpath = "") WebElement mCountry;
    @FindBy(xpath = "") WebElement mPostalCode;
    @FindBy(xpath = "") WebElement mPhoneNumber;

    public void addNewSupplierSubsidiary(JSONObject data) throws InterruptedException {

        this.supplierAccountSetupTab.click();
        this.supplierSubsidiarySubTab.click();
        Thread.sleep(2000);
        this.companySelect.click();
        Thread.sleep(2000);
        this.companySelected.click();
        Thread.sleep(2000);
        this.subsidiaryTaxID.sendKeys(data.get("subsidiaryTaxID").toString());
        this.subsidiaryName.sendKeys(data.get("subsidiaryName").toString());
        Thread.sleep(2000);
        this.subsidiaryTypeSelect.click();
        Thread.sleep(2000);
        this.subsidiaryTypeSelected.click();
        Thread.sleep(2000);
        this.notes.sendKeys(data.get("notes").toString());
        this.email.sendKeys(data.get("email").toString());
        this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
        this.website.sendKeys(data.get("website").toString());
        this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
        this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
        this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
        this.mCity.sendKeys(data.get("mCity").toString());
        this.mState.sendKeys(data.get("mState").toString());
        this.mCountry.sendKeys(data.get("mCountry").toString());
        this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
    }
}
