package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class corpCompanyPage {
    WebDriver driver;

    public corpCompanyPage(WebDriver driver){this.driver = driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/a") WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[1]/a") WebElement companySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-company-list/div/mat-drawer-container/mat-drawer-content/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]") WebElement basicDetailsPane;

    public void allCompanyListTest(){
        this.corpSetupTab.click();
        this.companySubTab.click();
        this.basicDetailsPane.click();
    }
}
