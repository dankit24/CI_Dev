<?php
if (isset($this->session->userdata['products'])) {
    $product1 = ($this->session->userdata['products']['product1']);
    $product2 = ($this->session->userdata['products']['product2']);
    $product3 = ($this->session->userdata['products']['product3']);
    $product4 = ($this->session->userdata['products']['product4']);
} else {
    header('location: home');
}
?>
<html>
    <head>
        <title>Shoping Cart</title>
        <link rel="stylesheet" href="<?php FCPATH ?>/assets/css/style.css">
    </head>
    <body>
        <section class="cart">
            <nav class="carthead">
                <ul align="center">
                    <li><a href=""><h1>Shopping Cart</h1></a></li>
                    <li><?php echo form_open('shoppingcart/emptycart'); ?>
                        <input type="submit" value="Empty Cart" name="empty">
                        <?php echo form_close(); ?></li>
                </ul>
            </nav>
            <p align="center" style="color: green;"><?php echo $succstatus; ?></p>
            <p align="center" style="color: red;"><?php echo $failstatus; ?></p>
            <div class="usercart">
                <table>
                    <thead>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                    </thead>
                    <tbody align="center">
                        <?php
                        error_reporting(0);
                        $gtotal = array();
                        foreach ($products as $key => $row) {
                            foreach ($row as $key2 => $row2) {
                                array_push($gtotal, strip_tags($row2['totalhide']));
                                foreach ($row2 as $row2) {
                                    echo $row2;
                                }
                            }
                        }
                        ?>
                        </tbody>
                </table>
                        <?php
                        echo '<p class="gtotal" align="center">Total Amount $' . array_sum($gtotal) . '</p>';
                        ?>
                    
            </div>
        </section>

        <section class="cartlist" align="center">
            <div class="cartsplit">
                <p align="center">Product Catalog</p>
            </div>

            <div class="cartitems">

                <p align="center"><img src="<?php echo $product1['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product1['name'] ?></p>
                <p align="center">$<?php echo $product1['price'] ?></p>

                <?php echo form_open('shoppingcart?p=product1'); ?>
                <table align="center">
                    <tr>
                        <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                        <td><input type="submit" value="add to cart"></td>
                    </tr>
                </table>
                <?php echo form_close(); ?>
            </div>

            <div class="cartitems">
                <p align="center"><img src="<?php echo $product2['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product2['name'] ?></p>
                <p align="center">$<?php echo $product2['price'] ?></p>

                <?php echo form_open('shoppingcart?p=product2'); ?>
                <table align="center">
                    <tr>
                        <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                        <td><input type="submit" value="add to cart"></td>
                    </tr>
                </table>
                <?php echo form_close(); ?>
            </div>

            <div class="cartitems">

                <p align="center"><img src="<?php echo $product3['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product3['name'] ?></p>
                <p align="center">$<?php echo $product3['price'] ?></p>

                <?php echo form_open('shoppingcart?p=product3'); ?>
                <table align="center">
                    <tr>
                        <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                        <td><input type="submit" value="add to cart"></td>
                    </tr>
                </table>
                <?php echo form_close(); ?>
            </div>

            <div class="cartitems">
                <p align="center"><img src="<?php echo $product4['image']; ?>" alt="product1"></p>
                <p align="center"><?php echo $product4['name'] ?></p>
                <p align="center">$<?php echo $product4['price'] ?></p>

                <?php echo form_open('shoppingcart?p=product4'); ?>
                <table align="center">
                    <tr>
                        <td><input type="number" name="qty" placeholder="Qty" min="1" max="10"></td>
                        <td><input type="submit" value="add to cart"></td>
                    </tr>
                </table>
                <?php echo form_close(); ?>
            </div>
        </section>
    </body>
</html>
