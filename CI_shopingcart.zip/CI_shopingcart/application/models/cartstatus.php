<?php

class cartstatus extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function addtocart($data, $products) {
        $oldcart = $this->session->userdata('cart');

        $products[$data['product']]['qty'] = $data['qty'];

        foreach ($oldcart as $key => $row) {
            $newcart = $products[$key]['qty'] + $row['qty'];
            $products[$key]['qty'] = $newcart;
        }

        $this->session->set_userdata('cart', $products);
    }

    public function emptycart() {
        $this->session->unset_userdata('cart');
    }

    public function removeitem($data) {
        $oldcart = $this->session->userdata('cart');
        unset($oldcart[$data['removeid']]);
        $this->session->set_userdata('cart', $oldcart);
    }

    public function loadcart() {
        $disitem = $this->session->userdata('cart');
        foreach ($disitem as $key => $row) {
            if ($row['qty'] >> 0) {
                $data[] = array($key => array('name' => "<tr><td>" . $row['name'] . "</td>",
                        'code' => "<td>" . $row['code'] . "</td>",
                        'qty' => "<td>" . $row['qty'] . "</td>",
                        'price' => "<td>" . "$" . $row['price'] . "</td>",
                        'total' => "<td>" . "$" . $row['qty'] * $row['price'] . "</td>",
                        'action' => "<td align='center'><a href=" . base_url() . "shoppingcart/removeitem?deleteId=$key><button class='removebtn'>Remove</button></a></td></tr>",
                        'totalhide' => "<td hidden>" . $row['qty'] * $row['price'] . "</td>",
                ));
            }
        }
        $data = array('products' => $data);
        return $data;
    }

}
