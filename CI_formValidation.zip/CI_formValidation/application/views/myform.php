<html>
    <head>
        <title>My Form</title>
    </head>
    <body>

        <?php echo form_open('form'); ?>
        <table>
            <tr>
                <td><h5>Username</h5></td>
                <td>
                    <input type="text" name="username" value="<?php echo set_value('username'); ?>" size="50" /><label><?php echo form_error('username'); ?></label>
                </td>
            </tr>
            <tr>
                <td><h5>Password</h5></td>
                <td>
                    <input type="text" name="password" value="<?php echo set_value('password'); ?>" size="50" /><label><?php echo form_error('password'); ?></label>
                </td>
            </tr>
            <tr>
                <td><h5>Password Confirm</h5></td>
                <td>
                    <input type="text" name="passconf" value="<?php echo set_value('passconf'); ?>" size="50" /><label><?php echo form_error('passconf'); ?></label>
                </td>
            </tr>
            <tr>
                <td><h5>Email Address</h5></td>
                <td>
                    <input type="text" name="email" value="<?php echo set_value('email'); ?>" size="50" /><label><?php echo form_error('email'); ?></label>
                </td>
            </tr>
            <tr><td>
            <div><input type="submit" value="Submit"></div>
            </td></tr>
    </table>

    </form>
</body>
</html>