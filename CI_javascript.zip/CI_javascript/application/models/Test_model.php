<?php
 
//file: application/models/test_model.php
 

class Test_model extends CI_Model {
 
    function __construct(){
        parent::__construct();
    }
 
    function get_data(){
 
        $type = $this->input->post('type');
 
        if($type != 1){
            return array();
        }
 
        return array(
            array(
                'name' => 'Ankit Desai',
                'email' => 'ankit@gmail.com',
                'Birth_date' => '24/12/1993'
            ),
            array(
                'name' => 'Atit Mistry',
                'email' => 'atit@gmail.com',
                'Birth_date' => '30/10/1993'
            ),
        );
    }
 
}