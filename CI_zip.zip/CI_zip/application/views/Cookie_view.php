<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Cookie Example</title>
    </head>
    <body>
        <a href="<?php FCPATH?>/cookie/create">click here</a> to create thee cookie.</br>
        <a href="<?php FCPATH?>/cookie/display">click here</a> to view the cookie.</br>
        <?php echo $cookie;?></br>
        <a href="<?php FCPATH?>/cookie/delete">click here</a> to delete the cookie.
    </body>
</html>