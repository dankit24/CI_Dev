<?php 
class Cookie_controller extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url','cookie','download'));
    }
    function index(){
        set_cookie('ankit','desai','3600');
        $this->load->view('Cookie_view');
    }
    function display_cookie(){
        $cookie =array('cookie' => get_cookie('ankit'));
        $this->load->view('Cookie_view',$cookie);
    }
    function deletecookie(){
        delete_cookie('ankit');
        $data = 'here is ankit';
        $name = 'myvideo.mp4';
        force_download($name,$data,NULL);
        redirect('cookie/display');
    }
}
?>